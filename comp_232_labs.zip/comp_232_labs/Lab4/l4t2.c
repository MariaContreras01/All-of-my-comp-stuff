/*
 
 Compile with: gcc -o l4t2 l4t2.c -I/usr/include/libxml2 -lxslt -lxml2
 
 */
 /**
* Name: Maria Contreras
* Lab/task: Lab 4 Task 2
* Date: 2/20/17
**/

#include <stdio.h>
#include <string.h>
#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xmlschemas.h>

int desc_flag = 0;

void error(const char *msg)
{
   fprintf(stderr, "ERROR: %s\n", msg);
   exit(1);
}

int is_valid(const xmlDocPtr doc, const char *schema_filename)
{
   xmlDocPtr schema_doc = xmlReadFile(schema_filename, NULL, XML_PARSE_NONET);
   if (schema_doc == NULL) {
      error("Failed to load XML schema.");
   }
   
   // See API at: http://xmlsoft.org/html/libxml-xmlschemas.html
   
   xmlSchemaParserCtxtPtr parser_ctxt = xmlSchemaNewDocParserCtxt(schema_doc);
   if (parser_ctxt == NULL) {
      error("Failed to create parsing context.");
   }
   
   xmlSchemaPtr schema = xmlSchemaParse(parser_ctxt);
   if (schema == NULL) {
      error("XML Schema in invalid.");
   }
   
   xmlSchemaValidCtxtPtr valid_ctxt = xmlSchemaNewValidCtxt(schema);
   if (valid_ctxt == NULL) {
      error("Failed to create validation context.");
   }
   
   int is_valid = (xmlSchemaValidateDoc(valid_ctxt, doc) == 0);
   
   xmlSchemaFreeValidCtxt(valid_ctxt);
   xmlSchemaFree(schema);
   xmlSchemaFreeParserCtxt(parser_ctxt);
   xmlFreeDoc(schema_doc);
   
   return is_valid;
}

void print_and_traverse( xmlNode* node )
{
   if(node -> properties)
   {
      printf("\n%-35s", node -> properties -> children -> content);
   }

   if( node -> children)
   {

      print_and_traverse(node -> children);
   }
   if( node -> next )
   {
      print_and_traverse(node -> next);
   }

   if(node -> parent -> name)
   {
      if(strcmp(node -> parent -> name, "course_number") == 0)
      {
         printf("%-10s", node -> content);
      }

      if(strcmp(node -> parent -> name, "unit_weight") == 0)
      {
         printf("%-10s", node -> content);
      }

      if(strcmp(node -> parent -> name, "description") == 0)
      {
         printf("\n%s\n", node -> content);
      }

      if(strcmp(node -> parent -> name, "instuctor") == 0)
      {
         printf("%-25s", node -> content);
      }

      if(strcmp(node -> parent -> name, "days_and_times") == 0)
      {
         printf("%-s\n", node -> content);
         printf("\n");
      }
   }
}

void print_catalog(xmlDocPtr doc)
{
   xmlNode *root_node = xmlDocGetRootElement(doc);
   
   print_and_traverse(root_node);
   
   // USE NAVIGATION FROM libxml2 API
   // http://xmlsoft.org/html/libxml-tee.html

}

int main(int argc, char **argv)
{
   (void) argc;
   (void) argv;
   
   if (argc < 3)
   {
      printf("Usage: l11q1 <xml file> <schema file>\n");
      exit(1);
   }

   // see API at: http://xmlsoft.org/html/libxml-parser.html
   
   printf("Loading %s\n", argv[1]);
   xmlDocPtr doc = xmlReadFile(argv[1], NULL, XML_PARSE_NONET | XML_PARSE_NOBLANKS);
   if (doc == NULL) {
      error("Failed to load.");
   }
   printf("Loaded.\n");
   
   printf("Validating with %s\n", argv[2]);
   if (!is_valid(doc, argv[2])) {
      error("Failed to validate.");
   }
   printf("Validated.\n");
   
   print_catalog(doc);
   
   xmlFreeDoc(doc);
   
   return 0;
}
