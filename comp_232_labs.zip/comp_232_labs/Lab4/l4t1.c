/**
* Name: Maria Contreras
* Lab/task: Lab 4 Task 1
* Date: 2/20/17
**/

#include <stdio.h>
#include <string.h>
//#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xmlschemas.h>

enum
{
   SEMESTER = 0,
   PROGRAM = 1,
   COURSE = 2,
   COURSE_NUMBER = 3,
   UNIT_WEIGHT = 4,
   DESCRIPTION = 5,
   INSTRUCTOR = 6,
   DAY_AND_TIME = 7,
};

int state = SEMESTER;
char data[1500];
int data_index = 0;
int desc_flag = 0;

xmlParserInputPtr resolveEntity(void *user_data, const xmlChar *publicId, const xmlChar *systemId)
{
   // printf("resolveEntity(publicId='%s', systemId='%s')\n", publicId, systemId);
   fflush(stdout);
   return NULL;
}

void internalSubset(void *user_data, const xmlChar *name, const xmlChar *ExternalID, const xmlChar *SystemID)
{
   // printf("internalSubset(name='%s', ExternalID='%s', SystemID='%s')\n", name, ExternalID, SystemID);
   fflush(stdout);
}

void externalSubset(void *user_data, const xmlChar *name, const xmlChar *ExternalID, const xmlChar *SystemID)
{
   // printf("externalSubset(name='%s', ExternalID='%s', SystemID='%s')\n", name, ExternalID, SystemID);
   fflush(stdout);
}

xmlEntityPtr getEntity(void *user_data, const xmlChar *name)
{
   // printf("getEntity(name='%s')\n", name);
   fflush(stdout);
   return NULL;
}

xmlEntityPtr getParameterEntity(void *user_data, const xmlChar *name)
{
   // printf("getParameterEntity(name='%s')\n", name);
   fflush(stdout);
   return NULL;
}

void entityDecl(void *user_data, const xmlChar *name, int type, const xmlChar *publicId, const xmlChar *systemId, xmlChar *content)
{
   // printf("entityDecl(name='%s', type=%i, publicId='%s', systemId='%s', content='%s')\n", name, type, publicId, systemId, content);
   fflush(stdout);
}

void notationDecl(void *user_data, const xmlChar *name, const xmlChar *publicId, const xmlChar *systemId)
{
   // printf("notationDecl(name='%s', publicId='%s', systemId='%s')\n", name, publicId, systemId);
   fflush(stdout);
}

void attributeDecl(void *user_data, const xmlChar *elem, const xmlChar *fullname, int type, int def, const xmlChar *defaultValue, xmlEnumerationPtr tree)
{
   (void)tree;
   // printf("attributeDecl(elem='%s', fullname='%s', type=%i, def=%i, defaultValue='%s')\n", elem, fullname, type, def, defaultValue);
   fflush(stdout);
}

void elementDecl(void *user_data, const xmlChar *name, int type, xmlElementContentPtr content)
{
   (void)content;
   // printf("elementDecl(name='%s', type=%i)\n", name, type);
   fflush(stdout);
}

void unparsedEntityDecl(void *user_data, const xmlChar *name, const xmlChar *publicId, const xmlChar *systemId, const xmlChar *notationName)
{
   // printf("unparsedEntityDecl(name='%s', publicId='%s', systemId='%s', notationName='%s')\n", name, publicId, systemId, notationName);
   fflush(stdout);
}

void setDocumentLocator(void *user_data, xmlSAXLocatorPtr loc)
{
   (void)loc;
   // printf("setDocumentLocator()\n");
   fflush(stdout);
}

void startDocument(void *user_data)
{
    //printf("startDocument()\n");
   fflush(stdout);
}

void endDocument(void *user_data)
{
   // printf("endDocument()\n");
   fflush(stdout);
}

void startElement(void *user_data, const xmlChar *name, const xmlChar **atts)
{
   int i;
   // printf("startElement(name='%s', atts=", name);
   fflush(stdout);
   if (atts != NULL) {
      // printf("{");
      fflush(stdout);
      for (i = 1; atts[i] != NULL; i+=2) 
      {
          printf("\n%-35s", atts[i]);
         fflush(stdout);
         if (atts[i + 1] != NULL) 
         {
             printf(", ");
         }
      }
      // printf("}");
      fflush(stdout);
   }
   if(strcmp((char *)name, "semester") == 0)
   {
      state = SEMESTER;
   }
   else if(strcmp((char *)name, "program") == 0)
   {
      state = PROGRAM;
   }
   else if(strcmp((char *)name, "course") == 0)
   {
      state = COURSE;
   }
   else if(strcmp((char *)name, "course_number") == 0)
   {
      state = COURSE_NUMBER;
   }
   else if(strcmp((char *)name, "unit_weight") == 0)
   {
      state = UNIT_WEIGHT;
   }
   else if(strcmp((char *)name, "description") == 0)
   {
      state = DESCRIPTION;
   }
   else if(strcmp((char *)name, "instuctor") == 0)
   {
      state = INSTRUCTOR;
   }
   else if(strcmp((char *)name, "days_and_times") == 0)
   {
      state = DAY_AND_TIME;
   }
   

   /*int i;
   printf("startElement(name='%s', atts=", name); //prints 'schedule'
   fflush(stdout);
   if (atts != NULL) 
   {
      printf("{");
      fflush(stdout);
      for (i = 0; atts[i] != NULL; i++) 
      {
         printf("'%s'", atts[i]);
         fflush(stdout);
         if (atts[i + 1] != NULL) 
         {
            printf(", ");
         }
      }
      printf("}");
      fflush(stdout);
   } else {
      printf("NULL");
      fflush(stdout);
   }
   printf(")\n");
   fflush(stdout);*/
}

void endElement(void *user_data, const xmlChar *name)
{
   switch(state)
   {
      case COURSE_NUMBER:
         printf("%-10s", data);
         memset(data, '\0', 1500);
         data_index = 0;
      break;

      case UNIT_WEIGHT:
         printf("%-10s", data);
         memset(data, '\0', 1500);
         data_index = 0;
      break;

      case DESCRIPTION:
         if(desc_flag)
         {
            printf("\n%s\n", data);
         }
         memset(data, '\0', 1500);
         data_index = 0;
      break;

      case INSTRUCTOR:
         printf("%-25s", data);
         memset(data, '\0', 1500);
         data_index = 0;
      break;

      case DAY_AND_TIME:
         printf("%-s\n", data);
         printf("\n");
         memset(data, '\0', 1500);
         data_index = 0;
         state = 0;
      break;

      default:
         memset(data, '\0', 1500);
         data_index = 0;
      break;
   }
   // printf("endElement(name='%s')\n", name);
   fflush(stdout);
}

void attribute(void *user_data, const xmlChar *name, const xmlChar *value)
{
    printf("attribute(name='%s', value='j%s')\n", name, value);
   fflush(stdout);
}

void reference(void *user_data, const xmlChar *name)
{
   // jprintf("reference(name='%s')\n", name);
   fflush(stdout);
}

void characters(void *user_data, const xmlChar *ch, int len)
{
   char *ptr_ch = (char *) ch;
   while (len-- > 0)
   {
      if (strchr("\n\t", *ptr_ch) == NULL)
      {
         data[data_index++] = (char)*ptr_ch;
      }
      ptr_ch++;
   }
   

   fflush(stdout);
}

void ignorableWhitespace(void *user_data, const xmlChar *ch, int len)
{
   
   char real_ch[len + 1];
   strncpy(real_ch, (char*)ch, len);
   real_ch[len] = 0;
   
   // printf("ignorableWhitespace(ch='%s', len=%i)\n", ch, len);
   fflush(stdout);
}

void processingInstruction(void *user_data, const xmlChar *target, const xmlChar *data)
{
   // printf("processingInstruction(target='%s', data='%s')\n", target, data);
   fflush(stdout);
}

void comment(void *user_data, const xmlChar *value)
{
   // printf("comment(value='%s')\n", value);
   fflush(stdout);
}

void cdataBlock(void *user_data, const xmlChar *value, int len)
{
   // printf("cdataBlock(value='%s', len=%i)\n", value, len);
   fflush(stdout);
}

void warning(void *user_data, const char *msg, ...)
{
   // printf("warning(msg='%s', ...)\n", msg);
   fflush(stdout);
}

void error(void *user_data, const char *msg, ...)
{
   // printf("error(msg='%s', ...)\n", msg);
   fflush(stdout);
}

void fatalError(void *user_data, const char *msg, ...)
{
   // printf("fatalError(msg='%s', ...)\n", msg);
   fflush(stdout);
}

int isStandalone(void *user_data)
{
   // printf("isStandalone()\n");
   fflush(stdout);
   return 1;
}

int hasInternalSubset(void *user_data)
{
   // printf("hasInternalSubset()\n");
   fflush(stdout);
   return 1;
}

int hasExternalSubset(void *user_data)
{
   // printf("hasExternalSubset()\n");
   fflush(stdout);
   return 1;
}

void startElementNs(void *user_data, const xmlChar *localname, const xmlChar *prefix, const xmlChar *URI, int nb_namespaces, const xmlChar **namespaces, int nb_attributes, int nb_defaulted, const xmlChar **attributes)
{
   int i;
   printf("startElementNs(localname='%s', prefix='%s', URI='%s', nb_namespaces=%i, namespaces={", localname, prefix, URI, nb_namespaces);
   fflush(stdout);
   for (i = 0; i < nb_namespaces; i++)
    {
      printf("'%s'", namespaces[i]);
      fflush(stdout);
      if (i + 1 < nb_namespaces) 
      {
         printf(", ");
      }
   }
   printf("}, nb_attributes=%i, nb_defaulted=%i, attributes={", nb_attributes, nb_defaulted);
   fflush(stdout);
   for (i = 0; i < nb_attributes; i++) 
   {
      printf("'%s'", attributes[i]);
      fflush(stdout);
      if (i + 1 < nb_attributes) 
      {
         printf(", ");
      }
   }
   printf("})\n");
   fflush(stdout);
}

void endElementNs(void *user_data, const xmlChar *localname, const xmlChar *prefix, const xmlChar *URI)
{
   
   // printf("endElementNs(localname='%s', prefix='%s', URI='%s')\n", localname, prefix, URI);
   fflush(stdout);
}

void serror(void *userData, xmlErrorPtr error)
{
   (void)userData;
   (void)error;
   // printf("serror()\n");
   fflush(stdout);
}


xmlSAXHandler saxHandler = {
   .internalSubset =  internalSubset,
   .isStandalone =  isStandalone,
   .hasInternalSubset =  hasInternalSubset,
   .hasExternalSubset =  hasExternalSubset,
   .resolveEntity =  resolveEntity,
   .getEntity =  getEntity,
   .entityDecl =  entityDecl,
   .notationDecl =  notationDecl,
   .attributeDecl =  attributeDecl,
   .elementDecl =  elementDecl,
   .unparsedEntityDecl =  unparsedEntityDecl,
   .setDocumentLocator =  setDocumentLocator,
   .startDocument =  startDocument,
   .endDocument =  endDocument,
   .startElement =  startElement,
   .endElement =  endElement,
   .reference =  reference,
   .characters =  characters,
   .ignorableWhitespace =  ignorableWhitespace,
   .processingInstruction =  processingInstruction,
   .comment =  comment,
   .warning =  warning,
   .error =  error,
   .fatalError =  fatalError,
   .getParameterEntity =  getParameterEntity,
   .cdataBlock =  cdataBlock,
   .externalSubset =  externalSubset,
   .startElementNs =  startElementNs,
   .endElementNs =  endElementNs,
   .serror =  serror,
   .initialized =  1,
};


int main(int argc, char **argv)
{
   if (argc != 2 && argc != 3) 
   {
      fprintf(stderr, "Syntax: %s (document.xml) [-d]\n", argv[0]);
      return 1;
   }

   if(argc == 3 && argv[2][0] == '-' && argv[2][1] == 'd')
   {
      desc_flag = 1;
   }

   memset(data, '\0', 1500);
   
   fprintf(stderr, "Runnig for: %s\n", argv[1]);
   xmlKeepBlanksDefault(0);
   xmlSAXUserParseFile(&saxHandler, NULL, argv[1]);
   fprintf(stderr, "Done with: %s\n", argv[1]);
   
   return 0;
}
