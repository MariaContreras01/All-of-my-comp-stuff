
# coding: utf-8

# In[23]:

get_ipython().magic('matplotlib inline')
import matplotlib.pyplot as plt
import numpy
from numpy import *
import numpy as np

data = np.genfromtxt('TG_SOUID1011572.txt', delimiter = ',')

print(data)

fig, ax = plt.subplots(figsize=(15,5))
ax.plot( data[:,3])
plt.xticks(range(0,20000,380), range(1966,2000),rotation='vertical')
#ax.plot((data[:,2]/10000)+(((data[:,2]%10000)-(data[:,2]%100/100))/12.0)+((data[:,2]%100)/365), data[:,3]) # list slicing in practice!
ax.axis('tight')
ax.set_title('tempeatures in Leba')
ax.set_xlabel('year')
ax.set_ylabel('temperature (C)');


# In[ ]:




# In[ ]:




# In[ ]:



