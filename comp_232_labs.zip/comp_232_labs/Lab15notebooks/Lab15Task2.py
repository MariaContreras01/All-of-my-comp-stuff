
# coding: utf-8

# In[40]:

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

def noise(array, x):
    new_array = []
    for point in array:
        # np.random.uniform(low=,high=)
        number = np.random.uniform(low=point - x, high=point+x)
        new_array.append(number)
    return new_array

def moving_average(array, y):
    new_array = []
    for i in range(len(array)-y):
        number = sum(array[i:i+y])/y
        new_array.append(number)
    return new_array
        
x = np.linspace(-1.5*np.pi, 1.55*np.pi, 256)
y = np.sin(x)
y2 = noise(y, .5)
y3 = moving_average(y2, 8)
plt.figure()
plt.plot(x, y, color='#cc0052', label='sin')
plt.plot(x, y2, color='#00cccc',label='noise')
x = x[:len(y3)]
plt.plot(x, y3, color='#00264d', label='smooth')
plt.xlabel('x')
plt.ylabel('y')
plt.title('title')
plt.legend()
plt.show()



# In[ ]:

#If you change the smoothing value to fifty the line gets smoother and looks more like a sin curve. This happens becuase youre getting a more precise average since  you're averaging out more things


# In[ ]:




# In[ ]:



