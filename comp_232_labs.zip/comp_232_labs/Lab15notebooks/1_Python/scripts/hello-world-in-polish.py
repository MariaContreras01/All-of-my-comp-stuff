#!/usr/bin/env python
# -*- coding: UTF-8 -*-

print("Dzień Dobry Świat!")
