//Maria Contreras
#include <stdio.h>
#include <stdlib.h>
#include "scanner.h"
#include "parser.h"

int main(void)
{
	AST_NODE *fullProgram = program();
	print_program(fullProgram);
	return 0;
}

//print using recursion