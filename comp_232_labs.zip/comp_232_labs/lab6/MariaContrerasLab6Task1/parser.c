//Maria Contreras
#include <stdio.h>
#include <stdlib.h>
#include "parser.h"
#include "scanner.h"
#include <string.h>

char *type_array[] = {"", "id", "number", "expr", "term", "assignStmt", "repeatStmt", "printStmt", 
                     "factor", "addOp", "multOp", "program", "statement"};

AST_NODE *program()
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = PROGRAM;
	node->left_node = statement();
	if(node->left_node != NULL)
	{
		node->right_node = program();
	}
	return node;
}

AST_NODE *statement()
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = STATEMENT;
	TOKEN *currToken = scanner();
	if(currToken->type == IDENTTOKEN)
	{
		node->left_node = assignStmt(currToken);
	}
	else if(currToken->type == REPEAT)
	{
		node->left_node = repeatStmt(currToken);
	}
	else if(currToken->type == PRINT)
	{
		node->left_node = printStmt(currToken);
	}

	return node;
}

AST_NODE *assignStmt(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = ASSIGN_STMT;
	node->left_node = id(currToken);
	expect(ASSIGNMENT);
	node->right_node = expr(currToken);
	expect(SEMICOLON);

	return node;

}

int expect(TOKEN_TYPE type)
{
	TOKEN *nextToken = scanner();
	if(nextToken->type == type);
	else
	{
		error();
	}
	return 0;
}

AST_NODE *repeatStmt(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = REPEAT_STMT;
	expect(LPAREN);
	node->left_node = expr(currToken);
	expect(RPAREN);
	node->right_node = statement();
	return node;
}

AST_NODE *printStmt(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = PRINT_STMT;
	node->left_node = expr(currToken);
	expect(SEMICOLON);
	return node;
}

AST_NODE *expr(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = EXPR;
	currToken = scanner();
	if( currToken->type == PLUS || currToken->type == MINUS)
	{
		node->left_node = expr(currToken);
		node->right_node = addOp(currToken);
		//node->data.addOp = currToken->strVal[0];
	}
	else
	{
		node->left_node = term(currToken);
	}
	ungetToken(&currToken);
	return node;
}

AST_NODE *term(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = TERM;
    currToken = scanner();
    if( currToken->type == MULT || currToken->type == DIV || currToken->type == MOD)
    {
    	node->left_node = term(currToken);
    	node->right_node = multOp(currToken);
    }
    else
    {
    	node->left_node = factor(currToken);
    }
    ungetToken(&currToken);
	return node;
}

AST_NODE *factor(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type =  FACTOR;
	currToken = scanner();
	if(currToken->type == IDENTTOKEN)
	{
		node->left_node = id(currToken);
	}
	else if(currToken->type == NUMBERTOKEN)
	{
		node->left_node = number(currToken);
	}
	else if(currToken->type == MINUS)
	{
		node->left_node = factor(currToken);
	}
	else if(currToken->type == LPAREN)
	{
		node->left_node = expr(currToken);
		expect(RPAREN);
	}
	return node;
}

AST_NODE *id(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = IDENTIFIER;
	if(currToken->type == IDENTTOKEN)
	{
		strcpy(node->data.identifier, currToken->strVal);
	}
	else
	{
		error();
	}
	return node;
}

AST_NODE *number(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = NUMBER;
	if(currToken->type == NUMBERTOKEN)
	{
		node->data.number = atof(currToken->strVal);
	}
	else
	{
		error();
	}
	return node;
}

AST_NODE *multOp(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = MULTOP;
	node->data.multOp = currToken->strVal[0];
	node->right_node = term(currToken);
	return node;
}

AST_NODE *addOp(TOKEN *currToken)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node->type = ADDOP;
	node->data.addOp = currToken->strVal[0];
	node->right_node = expr(currToken);
	return node;
}

void error()
{
	printf("You fucked up ¯\\_(ツ)_/¯\n");
	exit(-1);
}

void print_program(AST_NODE *fullProgram)
{
	AST_NODE *node = malloc(sizeof(AST_NODE));
	node = fullProgram;

	if(node->left_node == NULL && node->right_node == NULL)
	{
		printf("Traversing Tree: %s", type_array[node->type]);
		if(node->type == IDENTIFIER)
		{
			printf("Data: %s", node->data.identifier);
		}
		else if(node->type == NUMBER)
		{
			printf("Data: %f", node->data.number);
		}
	}
	if(node->type == ADDOP)
	{
		printf("Traversing tree: %s Data: %c", type_array[node->type], node->data.addOp);
	}
	else if(node->type == MULTOP)
	{
			printf("Traversing tree: %s Data: %c\n", type_array[node->type], node->data.multOp);
	}
	if(node->right_node == NULL)
	{
		printf("Traversing tree: %s\n", type_array[node->type]);
	}

	if(node->left_node != NULL)
	{
		print_program(node->left_node);
	}
	if(node->right_node != NULL)
	{
		print_program(node->right_node);
	}

}