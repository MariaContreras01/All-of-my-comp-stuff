#!/bin/bash
function back_up
{
	echo "Type the name of the file you want to backup"
	read -p "> " fileName

	if [ -d $fileName ]; then 
		tar -czf $path/$fileName-`date +%s`.tar.gz $fileName #make better time stamp(no one cares about seconds since 1970)
    else
    	echo "$fileName is not a directory"
	fi
}

function list 
{
	echo 'Do you want to list by (n)ame or (d)ate?'
	read -p ">" input
	case $input in
	n)
		ls -l $path 
		;;
	d)
 		ls -lt $path
 		;;
 	*)
		echo 'some text'
	esac
}

function restore
{
	echo 'What do you want to restore?'
	read -p ">" input
	rst=$(ls -t $path | grep $input | head -1)
	rst2=${rst::${#rst}-7}
	echo "$path/$rst"
	echo $rst2
	tar -zxf $path/$rst
}

function purge
{
	for f in *; do
  		fuckit=$(ls -t $path | grep "$f-" | sed -n '1!p')
  		for g in $fuckit; do
  			rm $path/$g
  		done
        #rm $fuckit
	done

}


path=./backup
if [ ! -d $path ]; then 
	mkdir $path
fi
while [ 0 ]
do
	echo "Would you like to backup, list, restore, purge or quit?"
	read -p "> " input

	case $input in 
	backup)
		back_up
	    ;;
	list)
		list
		;;
	restore)
		restore
		;;
	purge)
		purge
		;;
	quit)
		exit 0
		;;
	*)
		echo 'default'
	esac 
done 


