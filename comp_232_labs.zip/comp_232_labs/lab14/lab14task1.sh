#!/bin/bash
echo 'How many trials do you want?'
read -p ">" trials
deck=52

for i in {1..52}
do
	array[$i]=0
done

for (( i=0; $i<$trials; i=$i+1 ))
do
	DIV=$(($deck+1))
	R=$(($RANDOM%$DIV))
	array[$R]=$((${array}+1))
done

for i in {1..52}
do
	printf "$i) ${array[$i]} "
	for (( j=0; $j<${array[$i]}; j=$j+1))
	do
		printf '*'
	done
	echo
done

