/**
* Name: Maria Contreras
* Lab/task: Lab 5 Task 2
* Date: 2/27/17
**/
#include <stdio.h>
#include "scanner2.h"
#include <stdlib.h>

void printToken(TOKEN *t);

char *token_names[] = {"","number", "Identifier", "lparen", "rparen", 
                       "assignmet", "semicolon", "multop", "addop", "keyword"};

int main ()
{
	TOKEN *t;

	char trans_table[10][11];
	FILE *trans_in_file = fopen("table.txt", "r");
	char input[2];

	if(trans_in_file == NULL)
	{
		exit(-1);
	}

	for(int r = 0; r < 10; r++)
	{
		for(int c = 0; c < 11; c++)
		{
			fscanf(trans_in_file, "%s", input);
			trans_table[r][c] = input[0];
		}
	}

	while((t = scannerTT(trans_table)) != NULL)
	{
		printToken(t);
		t = NULL;
	}

	return 0;
}


void printToken(TOKEN *t)
{
	//based on t type 
	if(t->type == LPAREN || t->type == RPAREN || t->type == ASSIGNMENT || t->type == SEMICOLON)
	{
		printf("{<%s>}, ", token_names[t->type]);
	}
	else
	{
		printf("{<%s>, %s}, ", token_names[t->type],t->val);
	}
	//print val or not 
}