/**
* Name: Maria Contreras
* Lab/task: Lab 5 Task 2
* Date: 2/27/17
**/
#include <stdio.h>
#include "scanner2.h"
#include <string.h>
#include <stdlib.h>
#define MAX_SIZE 128

int isKeyword(char *in)
{
	return(!strcmp("print", in) || !strcmp("repeat", in));
}

TOKEN *scannerTT(char trans_table[][11])
{
	int state = 1;
    int col;
	TOKEN *t = malloc(sizeof(TOKEN));
	char ch;
    char temp[MAX_SIZE];
    char result;
    int temp_index = 0;

	while(1)
	{
		ch = getc(stdin);
		if(ch == EOF) return NULL;
		switch(ch)
		{
			case 'a'...'z':
				col = IDENTIFIER;
				break;

			case '0'...'9':
				col = NUMBER;
				break;

			case '(':
				col = LPAREN;
				break;

			case ')':
				col = RPAREN;
				break;

			case '=':
				col = ASSIGNMENT;
				break;

			case ';':
				col = SEMICOLON;
				break;

			case '*':
				col = MULTOP;
				break;

			case '/':
				col = MULTOP;
				break;

			case '%':
				col = MULTOP;
				break;

			case '+':
				col = ADDOP;
				break;

			case '-':
				col = ADDOP;
				break;

			case ' ':
			case '\n':
			case '\t':
				col = 9;
				break;

		}

		result = trans_table[state][col];
		if( result == 'a')
		{
			temp[temp_index] = '\0';
			ungetc(ch, stdin);
			t->type = trans_table[state][10] - '0';
			if(temp_index > 0)
			{
				t-> val = malloc(sizeof(char) * (temp_index + 1));
				if(t->type == IDENTIFIER)
				{
					if(isKeyword(temp))
					{
						t->type = KEYWORD;
					}
				}
				strcpy(t->val, temp);
			}
			return t;
		}
		else 
		{
			state = result - '0';
			if( col != 9)
			{
				temp[temp_index++] = ch;
			}
		}

	}
}