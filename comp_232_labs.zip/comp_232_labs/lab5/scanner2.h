#ifndef SCANNER_H
#define SCANNER_H
enum {
	NUMBER = 1, //0-9
	IDENTIFIER, // a-z
	LPAREN,     //(
	RPAREN,     //)
	ASSIGNMENT, //=
	SEMICOLON,  //;
	MULTOP,     //*
	ADDOP,
	KEYWORD};    //print, repeat};     //+

typedef struct token{
	int type;
	char *val; //id's keywords, numbers, multop,addop
}TOKEN;

TOKEN *scannerTT(char trans_table[][11]);
#endif