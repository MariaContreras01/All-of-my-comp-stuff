/**
* Name: Maria Contreras
* Lab/task: Lab 5 Task 1
* Date: 2/27/17
**/
#include <stdio.h>
#include "scanner.h"
#include <string.h>
#include <stdlib.h>
#define MAX_SIZE 128

int isKeyword(char *in)
{
	return(!strcmp("print", in) || !strcmp("repeat", in));
}

TOKEN *scannerEC(void)
{
	int state = 1;
	TOKEN *t = malloc(sizeof(TOKEN));
	char ch;
	char input[MAX_SIZE];
	int input_index = 0;

	while(1)
	{
		ch = getc(stdin);
		if(ch == EOF) return NULL;
		switch(state)
		{
			case 1:
				switch(ch)
				{
					case 'a'...'z':
						input[input_index++] = ch;
						state = 2;
						break;

					case '0'...'9':
						input[input_index++] = ch;
						state = 3;
						break;

					case '(':
						t->type = LPAREN;
						return t;

					case ')':
						t->type = RPAREN;
						return t;

					case '=':
						t->type = ASSIGNMENT;
						return t;

					case ';':
						t->type = SEMICOLON;
						return t;

					case '*':
						t->type = MULTOP;
						t-> val = malloc(sizeof(char) * 2);
						strcpy(t->val, "*");
						return t;

					case '/':
						t->type = MULTOP;
						t-> val = malloc(sizeof(char) * 2);
						strcpy(t->val, "/");
						return t;

					case '%':
						t->type = MULTOP;
						t-> val = malloc(sizeof(char) * 2);
						strcpy(t->val, "%");
						return t;

					case '+':
						t->type = ADDOP;
						t-> val = malloc(sizeof(char) * 2);
						strcpy(t->val, "+");
						return t;

					case '-':
						t->type = ADDOP;
						t-> val = malloc(sizeof(char) * 2);
						strcpy(t->val, "-");
						return t;
				}
				break;  
			case 2:
				switch(ch)
				{
					case 'a'...'z':
						input[input_index] = ch;
						input_index++;
						state = 2;
						break;

					default:
						input[input_index] = '\0';
						ungetc(ch, stdin);
						if(isKeyword(input))
						{
							t->type = KEYWORD;
							t->val = malloc(sizeof(char) * (strlen(input) + 1));
							strcpy(t->val, input);
						}
						else 
						{
							t->type = IDENTIFIER;
							t->val = malloc(sizeof(char) * (strlen(input) + 1));
							strcpy(t->val, input);
						}
						return t;
				}
				break;

			case 3:
				switch(ch)
				{
					case '0'...'9':
							input[input_index] = ch;
							input_index++;
							state = 3;
							break;

					default:
						input[input_index] = '\0';
						ungetc(ch, stdin);
						t->type = NUMBER;
						t->val = malloc(sizeof(char) * (strlen(input) + 1));
						strcpy(t->val, input);
						return t;
			    }
				break;
		}
	}
	//stuff
}