#ifndef SCANNER_H
#define SCANNER_H
enum {
	NUMBER = 0, //0-9
	IDENTIFIER, // a-z
	KEYWORD,    //print, repeat
	LPAREN,     //(
	RPAREN,     //)
	ASSIGNMENT, //=
	SEMICOLON,  //;
	MULTOP,     //*
	ADDOP};     //+

typedef struct token{
	int type;
	char *val; //id's keywords, numbers, multop,addop
}TOKEN;

TOKEN *scannerEC(void);
#endif