/**
* Name: Maria Contreras
* Lab/task: Lab 5 Task 2
* Date: 2/27/17
**/
#include <stdio.h>
#include "scanner.h"

void printToken(TOKEN *t);

char *token_names[] = {"number", "Identifier", "keyword", "lparen", "rparen", 
                       "assignmet", "semicolon", "multop", "addop"};

int main ()
{
	TOKEN *t;

	while((t = scannerEC()) != NULL)
	{
		printToken(t);
		t = NULL;
	}

	return 0;
}


void printToken(TOKEN *t)
{
	//based on t type 
	if(t->type == LPAREN || t->type == RPAREN || t->type == ASSIGNMENT || t->type == SEMICOLON)
	{
		printf("{<%s>}, ", token_names[t->type]);
	}
	else
	{
		printf("{<%s>, %s}, ", token_names[t->type],t->val);
	}
	//print val or not 
}