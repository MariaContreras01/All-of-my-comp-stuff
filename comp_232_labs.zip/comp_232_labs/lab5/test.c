#include <stdio.h>

int main(void) {
int x[128];

int i;

for(i = 'a'; i <= 'z'; i++) x[i] = 2;

printf("%d\n", x['k']);

}
