song('Smell Like Teen Spirit', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('In Bloom', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Come As You Are', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Breed', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Lithium', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Polly', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Territorial Pissings', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Drain You', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Lounge Act', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Stay Away', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('On a Plain', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Something In The Way', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Endless, Nameless', 'Nevermind', 'Nirvana', 'Grunge', 'Apple lossless', 790).
song('Five Years', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Soul Love', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Moonage Daydream', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Starman', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('It Aint Easy', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Lady Stardust', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Star', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Hang On To Yourself', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Ziggy Stardust', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Suffragette City', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 790).
song('Rock N Roll Suicide', 'Ziggy Stardust', 'David Bowie', 'Rock', 'Apple lossless', 390).
song('Speak To Me', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('Breathe(In The Air)', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('On The Run', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('Time', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('The Great Gig In The Sky', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('Money', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('Us And Them', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('Any Colour You Like', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('Brain Damage', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('Eclipse', 'Dark Side Of The Moon', 'Pink Floyd', 'Rock', 'Apple lossless', 420).
song('Brianstorm', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('Teddy Picker', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('D Is For Dangerous', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('Balaclava', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('Fluorescent Adolescent', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('Only Ones Who Know', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('Do Me A Favour', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('This House Is A Circus', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('If You Were There Beware', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('The Bad Thing', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('Old Yellow Bricks', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('505', 'Favourite Worst Nightmare', 'Arctic Monkeys', 'Rock', 'Apple lossless', 790).
song('Space Oddity', 'David Bowie', 'David Bowie', 'Rock', 'Apple lossless', 790).
song('Float On', 'Good News For People Who Love Bad News', 'Modest Mouse', 'Indie Rock', 'Apple lossless', 790).
song('Hollaback Girl', 'Love Angel Music Baby', 'Gwen Stefani', 'Pop', 'Apple lossless', 790).
song('Oh! Darling', 'Abbey Road', 'The Beatles', 'Rock', 'Apple lossless', 790).
