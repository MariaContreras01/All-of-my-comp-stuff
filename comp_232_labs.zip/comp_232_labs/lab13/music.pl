%look up songs by artist
artist(C):-
	song(A, B , C, D, E, F),
	write(A),
	nl,
	fail.

%look up songs by album
album(B):-
	song(A, B , C, D, E, F),
	write(A),
	nl,
	fail.

%look up songs by song
songs(A):-
	song(A, B , C, D, E, F),
	write(A),
	nl,
	fail.

%look up song by genre
genre(D):-
	song(A, B , C, D, E, F),
	write(A),
	nl,
	fail.

%look up artists by genre
genre2(D):-
	song(A, B , C, D, E, F),
	write(C),
	nl,
	fail.

%look up encodings by song
encodings(A):-
	song(A, B , C, D, E, F),
	write(E),
	nl,
	fail.

%look up songs by bit rate
bit(X):-
	song(A, B , C, D, E, F),
	((F > X) -> write(A), nl; write('')),
	fail.

%look up bit rates by song
bit2(A):-
	song(A, B , C, D, E, F),
	write(F),
	nl,
	fail.

