move(0, 0, 2).
move(0, 1, 1).
move(2, 1, 3).
move(2, 0, 0).
move(1, 0, 3).
move(1, 1, 0).
move(3, 0, 1).
move(3, 1, 2).
start(0).
stop(0).