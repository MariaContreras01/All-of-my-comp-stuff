/**
* Name: Maria Contreras
* Lab/task: Lab 7 Task 2
* Date: 3/13/17
**/
#ifndef l7t2_h_
#define l7t2_h_

#include <stdio.h>

typedef enum {
   IF = 258, // since Bison will start tokens at that number
   THEN,
   WHILE,
   DO,
   PRINT,
   ASSIGN,
   SEMICOLON,
   LPAREN,
   RPAREN,
   IDENTIFIER,
   NUMBER,
   MULTOP,
   ADDOP,
   // and so on...
} TOKEN;

#endif
