/**
* Name: Maria Contreras
* Lab/task: Lab 7 Task 2
* Date: 3/13/17
**/
#include "l7t2.h"
#include <stdio.h>

extern char *yytext;

int main(void) {
	TOKEN tok;

	char *keywords[] = {"if", "then", "while", "do", "print", "assign", "semicolon", "lparen", "rparen", "identifier", 
	                     "number", "multop", "addop"};

	while ((tok = yylex()) != 0)
	{
		tok-=IF;

		if(tok >= 0 && tok <= 4)
		{
			printf("{<keyword>%s}, ", yytext);
		}
		else
		{
			printf("{<%s>%s}, ", keywords[tok], yytext);
		}
	}
}
