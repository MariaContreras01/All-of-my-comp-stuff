/**
* Name: Maria Contreras
* Lab/task: Lab 7 Task 1
* Date: 3/13/17
**/
#include "l7t1.h"

extern double totDol;
extern double totNum;
extern int totKeywords[9];

extern FILE *yyin; /* needed if using yyin in here */
extern char* yytext;

char *targetWords[NUM_OF_WORDS] = {"bank", "dollar", "financ", "budget", "fund", "stock", "bond", "invest"};

int main(int argc, char *argv[])
{
	yyin = freopen(argv[1], "r", stdin);
	WORD word = NO_TOK;
	for (int i = 0; i < 9; ++i)
	{
		totKeywords[i] = 0;
	}
	while((word = yylex()) != NO_TOK)
	{
		if ((word > 0) && (word <= NUM_OF_WORDS))
		{
			printf("<!>%s<!>", yytext);
		}
	}

	int sumOfKeyWords = sum(totKeywords, 9);

	if(totDol >= 1000)
	{
		printf("\nVERY INTERESTING READING!\nReported sum of dollars: %.2f\n", totDol);
	}
	else if(sumOfKeyWords >= 3 && totNum > 1000)
	{
		printf("\nPOTENTIALLY INTERESTING READING!\nReported sum of numbers: %.2f\n", totNum);
		printf("Concordance:\n");
		for(int i = 0; i < 9; i++)
		{
			if(totKeywords[i+1] > 0)
			{
				printf("%d %s\n", totKeywords[i+1], targetWords[i]);
			}
		}
	}  
}

int sum(int array[], int size)
{
	int sum = 0;

	for(int i = 0; i < size; i++)
	{
		sum+=array[i];
	}
	return sum;
}

