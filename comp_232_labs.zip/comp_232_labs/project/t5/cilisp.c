//Maria Contreras
//Task 5
#include "cilisp.h"
#include <math.h>
#include <stdbool.h>

bool isVarFound(SYMBOL_TABLE* table, char* varName);

int main(void)
{
    yyparse();
    return 0;
}

void yyerror(char *s)
{
    fprintf(stderr, "%s\n", s);
}

// find out which function it is
int resolveFunc(char *func)
{
   char *funcs[] = { "neg", "abs", "exp", "sqrt", "add", "sub", "mult", "div", "remainder", "log", "pow", "max", "min", "exp2", "cbrt", "hypot", ""};
   
   int i = 0;
   while (funcs[i][0] !='\0')
   {
      if (!strcmp(funcs[i], func))
         return i;
         
      i++;
   }
   yyerror("invalid function"); // paranoic -- should never happen
   return -1;
}

// create a node for a number
AST_NODE *number(double value)
{
    AST_NODE *p;
    size_t nodeSize;

    // allocate space for the fixed sie and the variable part (union)
    nodeSize = sizeof(AST_NODE) + sizeof(NUMBER_AST_NODE);
    if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");
    
    p->symbolTable = NULL;
    p->parent = NULL;
    p->type = NUM_TYPE;
    p->data.number.value = value;

    return p;
}

// create a node for a function
AST_NODE *function(char *funcName, AST_NODE *op1, AST_NODE *op2)
{
    AST_NODE *p;
    size_t nodeSize;

    // allocate space for the fixed sie and the variable part (union)
    nodeSize = sizeof(AST_NODE) + sizeof(FUNCTION_AST_NODE);
    if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");
    
    p->symbolTable = NULL;
    p->parent = NULL;
    p->type = FUNC_TYPE;
    p->data.function.name = funcName;
    p->data.function.op1 = op1;
    p->data.function.op2 = op2;

    if(op1 != NULL)
    {
      op1->parent = p;
    }

    if(op2 != NULL)
    {
      op2->parent = p;
    }

    return p;
}

//create a node for symbol
AST_NODE *symbol(char *symName)
{
  AST_NODE *p;
  size_t nodeSize;

  //allocate space for the fixed size and variable part (union)
  nodeSize = sizeof(AST_NODE) + sizeof(SYMBOL_AST_NODE);
  if((p = malloc(nodeSize))== NULL)
    yyerror("out of memory");
  
  p->symbolTable = NULL;
  p->parent = NULL;
  p->type = SYMBOL_TYPE;
  p->data.symbol.varName = symName;

  return p;
}

//links table to s-expr
AST_NODE *let_list(SYMBOL_TABLE *table, AST_NODE *expr)
{
  expr->symbolTable = table;
  return expr;
}

//assigns the vars and values 
SYMBOL_TABLE *assign(char* symbol, AST_NODE* expr)
{
  SYMBOL_TABLE *table; 
  size_t tableSize;    

  tableSize = sizeof(SYMBOL_TABLE);
  if((table = malloc(tableSize)) == NULL)
    yyerror("out of memory");

  table->var = symbol;
  table->value = expr;
  table->next = NULL;

  return table;
}

//adds node to the end of the symbol table list
SYMBOL_TABLE *append(SYMBOL_TABLE* list, SYMBOL_TABLE* node)
{
  SYMBOL_TABLE *tempList  = list;
  while(tempList->next != NULL)
  {
    tempList = list->next;
  }

  tempList->next = node;
  return list; //I have no idea how the fuck this works but it works
}

//checks for compilation errors
void checkDefs(AST_NODE* p)
{
  if(p->type == SYMBOL_TYPE)
  {
    AST_NODE* current = p;
    while( current != NULL)
    {
      if(isVarFound(current->symbolTable, p->data.symbol.varName)) 
      {
        return;
      }
      current = current->parent;
    }
    char* err;
    asprintf(&err, "%s not defined", p->data.symbol.varName);
    yyerror(err);
    free(err);
  }
  else if(p->type == FUNC_TYPE)
  {
    if(p->data.function.op1 != NULL)
      checkDefs(p->data.function.op1);
    if(p->data.function.op2 != NULL)
      checkDefs(p->data.function.op2);
  }

  SYMBOL_TABLE* current = p->symbolTable;
  while(current != NULL)
  {
    checkDefs(current->value);
    current = current->next;
  }

}

//checks for missing variables
bool isVarFound(SYMBOL_TABLE* table, char* varName)
{
  SYMBOL_TABLE* current = table;
  bool varFound = false;
  while( current != NULL )
  {
    if(strcmp(varName, current->var) == 0)
    {
      varFound = true;
      break;
    }
    current = current->next;
  }
  return varFound;
}

// free a node
void freeNode(AST_NODE *p)
{
    if (!p)
       return;
       
    if (p->type == FUNC_TYPE)
    {
        free(p->data.function.name);
        freeNode(p->data.function.op1);
        freeNode(p->data.function.op2);
    }
        
    free (p);
}

double eval(AST_NODE *p)
{
    //int i = resolveFunc(p->data.function.name);
    if (!p)
       return 0.0;

    else if(p->type == NUM_TYPE)
    {
        return p->data.number.value;
    }
    else if( p->type == FUNC_TYPE)
    {
        int i = resolveFunc(p->data.function.name);
        AST_NODE* op1 = p->data.function.op1;
        AST_NODE* op2 = p->data.function.op2;
        switch(i)
        {
          case 0:
            return -eval(op1);

          case 1:
            return fabs(eval(op1));

          case 2:
            return exp(eval(op1));

          case 3:
            return sqrt(eval(op1));

          case 4: 
            return eval(op1) + eval(op2);

          case 5: 
            return eval(op1) - eval(op2);

          case 6:
            return eval(op1) * eval(op2);

          case 7:
            return eval(op1) / eval(op2);

          case 8: 
            return fmod(eval(op1), eval(op2));

          case 9:
            return log(eval(op1));

          case 10:
            return pow(eval(op1), eval(op2));

          case 11:
            return fmax(eval(op1), eval(op2));

          case 12:
            return fmin(eval(op1), eval(op2));

          case 13:
            return exp2(eval(op1));

          case 14: 
            return cbrt(eval(op1));

          case 15:
            return hypot(eval(op1), eval(op2));
        }
    }
    else if(p->type == SYMBOL_TYPE)
        {
          AST_NODE* val = NULL;
          AST_NODE* currentNode = p;
          while(currentNode != NULL)
          {
            SYMBOL_TABLE* currentTable = currentNode->symbolTable;
            while(currentTable != NULL)
            {
              if(strcmp(currentTable->var, p->data.symbol.varName) == 0)
              {
                val = currentTable->value;
              }

              currentTable = currentTable->next;
            }

            if(val != NULL)
            {
              return eval(val);
            }
            currentNode = currentNode->parent;
          }
          printf("undefined variable\n");
          exit(1);
        }
    return 0.0;   
// TBD: implement
}  

