#ifndef __cilisp_h_
#define __cilisp_h_

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>

#include "cilisp.tab.h"

int yyparse(void);
int yylex(void);
void yyerror(char *);

typedef enum { NUM_TYPE, FUNC_TYPE, SYMBOL_TYPE } AST_NODE_TYPE;

typedef struct
{
    double value;
} NUMBER_AST_NODE;

typedef struct
{
   char *name;
   struct ast_node *op1;
   struct ast_node *op2;
} FUNCTION_AST_NODE;

typedef struct 
{
   char *varName;
}SYMBOL_AST_NODE;

typedef struct dType//real or integer
{
   char *dType;
}TYPE_AST_NODE;

typedef struct symbol_table
{
   //SYMBOL_TABLE* next;
   struct symbol_table* next; //cuz you need to keep track of the name and the reference and all that stuff
   char* var;
   char* type;
   struct ast_node* value;
   struct dType* dataType;

}SYMBOL_TABLE;

typedef struct ast_node
{
   AST_NODE_TYPE type;//func, num, or symbol
   SYMBOL_TABLE* symbolTable;
   union
   {
      NUMBER_AST_NODE number;
      FUNCTION_AST_NODE function;
      SYMBOL_AST_NODE symbol;
      TYPE_AST_NODE dataType;
   } data;
   struct ast_node* parent;
} AST_NODE;



AST_NODE *number(double value);
AST_NODE *function(char *funcName, AST_NODE *op1, AST_NODE *op2);
AST_NODE *symbol(char *symName);
AST_NODE *let_list(SYMBOL_TABLE *table, AST_NODE *expr);
SYMBOL_TABLE *assign(char* datType, char* symbol, AST_NODE* expr);
void checkDefs(AST_NODE* p);
SYMBOL_TABLE *append(SYMBOL_TABLE* list, SYMBOL_TABLE* node);
void freeNode(AST_NODE *p);

double eval(AST_NODE *ast);

#endif
