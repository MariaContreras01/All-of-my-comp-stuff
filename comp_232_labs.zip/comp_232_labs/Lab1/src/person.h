/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 8
* Date: 02/05/17
**/

#ifndef PERSON_H_ /* tp prevent re-definitions */
#define PERSON_H_ /* that cause errors */

typedef char NAME[41];

typedef struct date
{
	int month;
	int day;
	int year;
} DATE;

typedef struct person 
{
	NAME name;
	int age;
	float height;
	DATE bday;
} PERSON;

int add(PERSON *p);
#endif