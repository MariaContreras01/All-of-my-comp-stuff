/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 8
* Date: 02/05/17
**/

#include <stdio.h>
#include "person.h"

int add(PERSON *p)
{
  printf("enter name, age, and height");
  scanf("%s%d%f", p->name, &p->age, &p->height);

  return 1;
}