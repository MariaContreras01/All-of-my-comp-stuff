/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 6
* Date: 02/05/17
**/

#include <stdio.h>
#include <string.h>
#define MAX_SIZE 100
int main(void) {
	/* file handles */
	FILE *input_file =NULL;
	FILE *output_file=NULL;
	char name[MAX_SIZE];
	int ch; 
	/*ask user for the name of the file to read into*/
	printf("What's the name of the file you want to read into?");
	scanf("%s", name);

	/* open files for writing*/
    input_file = fopen("data.txt", "r");
	output_file = fopen(name, "w");
	if(output_file == NULL)
	{
		return(1);    /* need to do explicit ERROR CHECKING */
	}

    /* write some data into the file */
	while((ch = fgetc(input_file)) != EOF)
	{
		fputc(ch, output_file);
	}

	/* don’t forget to close file handles */
	fclose(input_file);
	fclose(output_file); 
	
    return 0;
}
