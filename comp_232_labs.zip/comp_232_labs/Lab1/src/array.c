/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 4
* Date: 02/05/17
**/

#include <stdio.h>

#define NUM_OF_ELEMENTS 12

int main(void) 
{
    double data[NUM_OF_ELEMENTS]; /* 12 cells, one cell per student */
    int index;
    double sum = 0.0;
    double average = 0.0;
		/* Always initialize array before use */

    for (index = 0; index < NUM_OF_ELEMENTS; index++) 
    {
        scanf("%lf", &data[index]);
    }
    /* now, number[index]=index; will cause error:why ?*/

    for (index = 0; index < NUM_OF_ELEMENTS; index = index + 1) 
    {
	    sum += data[index];  /* sum array elements */
        printf("%.1lf,",data[index]);
    }

    average = sum / NUM_OF_ELEMENTS;
    printf(" \n Average: %.1lf \n", average);

    
	
    return 0;
}
