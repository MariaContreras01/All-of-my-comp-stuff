/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 2
* Date: 01/28/17
**/

#include <stdio.h>

int main(void)
{
	int nstudents = 0; /* Initialization, required */
	int nfaculty = 0;
	double ratio = 0.0;
	
	printf("How many students does CSUCI have ????:");
 	scanf ("%d", &nstudents);  /* Read input */
	printf("CSUCI has %d students.\n", nstudents); 

	printf("How much faculty does CSUCI have?:");
	scanf("%d", &nfaculty); /*read input*/
	printf("CSUCI has %d faculty. \n", nfaculty);

	ratio = nstudents / nfaculty;

	printf("The student to faculty ratio is %.1lf \n", ratio);

}


