/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 5
* Date: 02/05/17
**/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_WORDS 100 /* max number of words*/
#define MAX_LENGTH 100/*max letters per word*/
int main(void)
{
	char* words[MAX_WORDS];
	int count = 0; /* counts the number of words you're reading*/
	while(!feof(stdin))
	{
		char temp[MAX_LENGTH]; /*temprary array to hold the words*/
		scanf("%s\n", temp); 
		words[count] = malloc(sizeof(char)*strlen(temp) + 1); 
		strcpy(words[count], temp); /* copy from temp into words*/
		count++; /*increment counter*/
	}

    printf("Number of read words: %d\n", count);
	for(int i = 0; i < count; i++)
	{
		printf("%s\n", words[i]); /*print the words on a new line*/
	}
	//free(words);
	return 0;
}