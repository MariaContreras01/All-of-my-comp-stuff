/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 8
* Date: 02/05/17
**/

#include <stdio.h>
#include "person.h"
#include <stdlib.h>
#define MAX_SIZE 100
/*struct birthday{
    int month;
    int day;
    int year;*/
 

int main() { 
  //struct birthday mybday;	/* - no ‘new’ needed ! */
  PERSON *employees[MAX_SIZE]; 
  int numOfEmployees;
 				/* then, it’s just like Java ! */
  printf("Enter the number of employees");
  scanf("%d", &numOfEmployees);

  for(int i = 0; i < numOfEmployees; i++)
  {
  	employees[i] = malloc(sizeof(PERSON));
  	add(employees[i]);
  }

  for(int i = 0; i < numOfEmployees; i++)
  {
  	printf("Name: %s\n Age: %d\n height: %.1f\n", employees[i]->name, employees[i]->age, employees[i]->height);
  }  
 //free(employees);
}
