/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 9
* Date: 02/05/17
**/

#ifndef MESSAGE_H_ /*to prevent redifintions */
#define MESSAGE_H_ /*that cause */

typedef struct message 
{
	unsigned short type;
	union
	{
		char chars[16];
		int ints[4];
		float floats[2];
		char *words;
		
	};
} MESSAGE; 
#endif 
