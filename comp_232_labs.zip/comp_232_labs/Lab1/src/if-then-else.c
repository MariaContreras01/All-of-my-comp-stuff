/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 3
* Date: 02/05/17
**/

#include <stdio.h>
#define DANGERLEVEL 5    /* C Preprocessor -
			- substitution on appearance */
				/* like Java ‘final’ */
int main(void)
{
	//float level=1;
	float level = 0;
	printf("What is the level?");
	scanf("%f", &level);

	/* if-then-else as in Java */

	if (level <= DANGERLEVEL) /*replaced by 5*/
      		printf("Low on gas!\n");
	else
		printf("Good driver !\n");
}
