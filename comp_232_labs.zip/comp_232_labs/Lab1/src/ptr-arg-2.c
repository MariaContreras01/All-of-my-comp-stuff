/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 7
* Date: 02/05/17
**/

#include <stdio.h>

void swap(char **, char **);

int main() {
  char* str1 = "mames";
  char* str2 = "no";
  swap(&str1, &str2);
  printf("str1 = %s and str2 = %s\n", str1, str2);

  return 0; 
}

void swap(char **s1, char **s2) { /* passed and returned by 						reference */
  char* temp;

  temp = *s1;
  *s1 = *s2;
  *s2 = temp;
}
