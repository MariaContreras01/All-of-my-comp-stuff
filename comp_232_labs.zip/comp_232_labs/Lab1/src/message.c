/**
* Name: Maria Contreras
* Lab/task: Lab 1 Task 9
* Date: 02/05/17
**/
#include <stdio.h>
#include "message.h"
#define MAX_SIZE 16

int message_dispatcher();
int main(void)
{
	MESSAGE* cache[MAX_SIZE];
	MESSAGE type;
	int i = 0;


	while(scanf("%hd",&type.type) != EOF)
	{
		scanf("%hd", &type.type);
		switch (type.type)
		{
			case 1: //16 characters
			scanf("%s", cache[i]->chars);
			break;

			case 2://4 ints
			scanf("%d %d %d %d", &cache[i]->ints[0], &cache[i]->ints[1], &cache[i]->ints[2], &cache[i]->ints[3]);
			break;

			case 3://2 floats
			scanf("%f %f", &cache[i]->floats[0], &cache[i]->floats[1]);
			break;

			case 4: //word
	     	scanf("%s", cache[i]->words);
	     	break;
		}

		i++;
	}

}

int message_dispatcher()
{
	return 0;
}