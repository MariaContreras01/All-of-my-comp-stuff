//Program that calculates the sum of the first 4 multiples of seven
//Maria Contreras
//2-28-15

public class MultiplesOfSeven
{
  public static void main( String [] args )
  {
    int sum = 0;
    int countMultiplesOf7= 0;
    int count = 1;
    final int SENTINEL = 4;
    
    while( count <= SENTINEL )
    {
      countMultiplesOf7+=7;
      sum+=countMultiplesOf7;
      count++;
    }
    
    System.out.println( "The sum of the first 4 multples of seven is " + sum );
  }
}