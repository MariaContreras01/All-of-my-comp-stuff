//program that asks user for ID number
//Maria Contreras
//2-28-15

import java.util.Scanner;

public class IdNumber
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    String idNumber;
    int counter = 0;
    
    System.out.print( "Enter your ID number" );
    idNumber = scan.nextLine();
    
    for ( int i = 0; i < idNumber.length(); i++ );
    {
      counter++;
      if ( counter == 2 )
      {
        System.out.println( "ID number is valid" );
      }
      
      if ( counter > 2 || counter < 2 )
      {
        System.out.println( "ID number is invalid" );
      }
    }
    
  }
}