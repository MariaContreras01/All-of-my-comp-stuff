//program that takes integer input form user and prompts user for additional input until user enters 20
//Maria Contreras
//2-28-15

import java.util.Scanner;

public class Integer
{
  public static void main( String [] args ) 
  {
    Scanner scan = new Scanner( System.in );
    System.out.print( "Enter a starting integer" );
    int start = scan.nextInt();
    int newInteger = 0;
    final int SENTINEL = 20;
    
    while ( newInteger != SENTINEL )
    {
      System.out.println( start );
      System.out.println( "Enter another integer" );
      newInteger = scan.nextInt();
      
      if ( newInteger >= start )
      {
        System.out.println( newInteger );
      }
    }
  }
}
