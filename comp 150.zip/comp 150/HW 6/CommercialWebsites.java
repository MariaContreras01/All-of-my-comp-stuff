//Website that counts how mainy commercial websites the user enters and outputs the count
//Maria Contreras
//2-28-15

import java.util.Scanner;
  
public class CommercialWebsites
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    String websiteName;
    String websiteName2 = "";
    int count = 0;
    
    System.out.println( "Enter a website name" );
    websiteName = scan.nextLine();
    
    while (!(websiteName2.equals( "stop" )))
    {
      if( websiteName.endsWith(".com"))
      {
        count++;
        System.out.println("Enter another website");
        websiteName2 = scan.nextLine();
      }
    }
      System.out.println( "The number of commercial websites entered is " + count );
  } 
}
