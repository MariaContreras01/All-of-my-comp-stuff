//program that reads a text file 
//Maria Contreras
//2-18-15

import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class ReadAFile
{
  public static void main( String [] args ) throws IOException
  {
    File inputFile = new File( "Logic.txt" );
    Scanner scan = new Scanner( inputFile );
    String word = "";
    String replaceVowels = "";
    int counter = 1;
    
    while ( scan.hasNext())
    {
      word = scan.nextLine();
      if ( word.startsWith( "is"));
      {
        counter++;
        word = word.replaceAll( "[aeiou]", "~" );
      }
     System.out.println( word );
     System.out.println( counter + " word(s) start with is " ); 
    }
  }
}