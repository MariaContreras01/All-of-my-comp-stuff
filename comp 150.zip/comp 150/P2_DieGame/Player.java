import java.util.Random;

/**
 * Player class for the game of Odd or Even
 *
 * @author: Maria Contreras
 * @version: 03/03/15
 */
public class Player
{
    // Declare instance variables here
    private String name;
    private String guess;
    private int points;

    /**
     * Constructor  sets the name to the given playersName,
     *                   guess is set to empty string, and points to 0
     *
     * @param playerName The player's name
     */
    public Player(String playerName)
    {
        this.name = playerName;
        this.guess = "";
        System.out.println("In Player constructor - IMPLEMENT ME");
    }

    /**
     * The makeGuess method causes the player to guess either EVEN or ODD
     * Creates a random object and utilizes nextBoolean method
     */
    public void makeGuess()
    {
    Random rand = new Random(); 
    boolean evenOrOdd = rand.nextBoolean();
    
    if ( evenOrOdd == true )
    {
      this.guess = "even";
    }
    else 
    {
      this.guess = "odd";
    }
        System.out.println("Your guess is " + guess);
    }

    /**
     * The addPoint method adds one point to the player's current balance
     */
    public void addPoint()
    {
        this.points++;
        System.out.println("your points are " + points);
    }

    /**
     * Accessor method
     *
     * @return the player's name field
     */
    public String getName()
    {
        return this.name; 
    }

    /**
     * Accessor method
     *
     * @return the value of the guess field
     */
    public String getGuess()
    {
        return this.guess;  
    }

    /**
     * Accessor method
     *
     * @return the value of the points field
     */
    public int getPoints()
    {
        return this.points; 
    }

    /**
     * @return the String representation of the content of the player's object:
     *                    only players name and the numbers of points are given
     */
    public String toString()
    {
        return "The player name is " + this.name +
                "\nThe points are " + this.points;    
    }
}