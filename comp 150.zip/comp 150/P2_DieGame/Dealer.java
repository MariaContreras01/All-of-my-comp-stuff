/**
 * Dealer class for the game of Even Or Odd
 *
 * @author Maria Contreras
 * @version: 03/03/15
 */
public class Dealer
{
    // Declare instance variables here
    private Die die1;
    private Die die2;
    private final int SIDES = 6;
    

    /**
     * Constructor  creates two Die objects
     */
    public Dealer()
    {
        Die die1 = new Die(SIDES);
        Die die2 = new Die(SIDES);
        System.out.println("In Dealer constructor - IMPLEMENT ME");
    }

    /**
     * The shakeDiceCup method rolls both dice
     */
    public void shakeDiceCup()
    {
        die1.roll();
        die2.roll();
        System.out.println("In shakeDiceCup method - IMPLEMENT ME");
    }

    /**
     * The calculateEvenOrOdd method returns the result of the dice roll
     *
     * @return EVEN if the sum of two dice roll is even, or ODD otherwise
     */
    public String calculateEvenOrOdd()
    {
      String result;
      if ((die1.getFace() + die2.getFace()) % 2 == 0)
      {
        result = "EVEN";
      }
      else
      {
        result = "ODD";
      }
      
        System.out.println("In calculateEvenOrOdd method - IMPLEMENT ME");

        return result;  
    }

    /**
     * @return String representation of the dealer's roll
     */
    public String toString()
    {
        return "The dealer rolled " + this.die1 + this.die2;   // THIS IS A STUB
    }
}