
import java.util.Random;

public class EvenOddTest
{
  public static void main( String [] args )
  {
    String guess;
    Random rand = new Random(); 
    boolean evenOrOdd = rand.nextBoolean();
    
    if ( evenOrOdd == true )
    {
      guess = "even";
    }
    else 
    {
      guess = "odd";
    }
    System.out.println(evenOrOdd + " " + guess);
  }
}