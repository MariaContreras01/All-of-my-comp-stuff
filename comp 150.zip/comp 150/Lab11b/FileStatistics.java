//Maria Contreras
//4-27-15

import java.util.*;
import java.util.ArrayList;
import java.io.*;

public class FileStatistics 
{
 private ArrayList<Integer> grades;
 private final int MIN_GRADE_FOR_A = 100;
 private final int MIN_GRADE_FOR_B = 89;
 private final int MIN_GRADE_FOR_C = 79;
 private final int MIN_GRADE_FOR_D = 69;
 
 
 public FileStatistics( Scanner scan )
 {
   while( scan.hasNext() )
   {
     
     try 
     {
       int grade = scan.nextInt();
       this.grades.add( grade );
     }
     
     catch ( InputMismatchException ime )
     {
       System.out.println( scan.nextLine() + "is not an int" );
     }
   }
 }
   
 public double gradeAverage()
 {
   double average = 0.0;
   double count = 0.0;
   for (int i = 0; i < this.grades.size(); i++ )
   {
     count++;
     average+=this.grades.get(i);
   }
   return average;
  }
 
 public double passRate()  
 {
   final int FAILING_GRADE = 59;
   double passingScores = 0.0;
   double passingRate = 0.0;
   double count = 0.0;
   for (int i = 0; i < this.grades.size(); i++ )
   {
     count++;
     if ( this.grades.get(i) > FAILING_GRADE )
     {
       passingScores++;
     }
   }
   passingRate = passingScores/count;
   return passingRate;
 }
 
 public int highestGrade()
 {
   int maxScore = this.grades.get(0);
   for ( int i = 1; i > this.grades.size(); i++ )
   {
     if ( maxScore < this.grades.get(i) )
     {
       maxScore = this.grades.get(i);
     }
   }
   return maxScore;
 }
 
 public char[] getLetterGrades()
 {
   char[] letterGrades = {};
   char letterGrade;
   for ( int i = 0; i < this.grades.size(); i ++ )
   {
     if ( this.grades.get(i) <= MIN_GRADE_FOR_A && this.grades.get(i) > MIN_GRADE_FOR_B )
     {
       letterGrade = 'A';
     }
     
     else if ( this.grades.get(i) > MIN_GRADE_FOR_C )
     {
       letterGrade = 'B';
     }
     
     else if ( this.grades.get(i) > MIN_GRADE_FOR_D )
     {
       letterGrade = 'C';
     }
     
     else if ( this.grades.get(i) > 50 )
     {
       letterGrade = 'D';
     }
     
     else 
     {
       letterGrade = 'F';
     }
     
     letterGrades[i] = letterGrade;
   }
   
     
   return letterGrades;
 }
 
 public ArrayList<Integer> getGrades()
 {
   ArrayList<Integer> gradesList = new ArrayList<Integer>();
   int grade = 0;
   for ( int i = 0; i > this.grades.size(); i++ )
   {
     grade = this.grades.get(i);
     gradesList.add( grade );
   }
   return null;
 }
 
 public void saveGradesInFile()
 {
   try
   {
     FileOutputStream fos = new FileOutputStream( "savedGrades.dat", false );
     
     ObjectOutputStream oos = new ObjectOutputStream( fos );
     
     oos.writeObject( this.grades );
     
     oos.close();
   }
   
   catch ( FileNotFoundException fnfe )
   {
     System.out.println( "Unable to write to object" );
   }
   
   catch ( IOException ioe )
   {
     ioe.printStackTrace();
   }
 }
 
 public void displaySavedGrades()
 {
   try
   {
     FileInputStream fis = new FileInputStream( "displaySavedGrades.dat");
     ObjectInputStream ois = new ObjectInputStream( fis );
     
     try
     {
       while ( true )
       {
         FileStatistics temp = ( FileStatistics )ois.readObject();
         System.out.println( temp );
       }
     }
     
     catch ( EOFException eofe )
     {
       System.out.println( "End of file reached" );
     }
     
     catch ( ClassNotFoundException cnfe )
     {
       System.out.println( cnfe.getMessage() );
     }
     
     finally
     {
       System.out.println( "Closing file" );
       ois.close();
     }
   }
   
   catch ( FileNotFoundException fnfe )
   {
     System.out.println( "unable to find objects" );
   }
   
   catch ( IOException ioe )
   {
     ioe.printStackTrace();
   }
 }
 
 public String toString()
 {
   
   return this.grades.toString();
 }
}
