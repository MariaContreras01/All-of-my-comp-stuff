/**   Lab8b
  *   @author YOUR NAME
  *   @version 3/17/2014
  */
import java.util.*;
public class ArrayMethodsClientL8b
{ 
  public static void main( String [] args )
  {
    // declare and initialize array of integers in ascending order
    int [] intNumbersSortedA = { 1, 2, 3, 4, 5, 6 };
    
    // STEP 5 
    // declare and initialize an array with 10 randomly generated 
    //     numbers between 1 and 9
    Random rand = new Random();
    int num1 = rand.nextInt( 9 ) + 1;
    int num2 = rand.nextInt( 9 ) + 1;
    int num3 = rand.nextInt( 9 ) + 1;
    int num4 = rand.nextInt( 9 ) + 1;
    int num5 = rand.nextInt( 9 ) + 1;
    int num6 = rand.nextInt( 9 ) + 1;
    int num7 = rand.nextInt( 9 ) + 1;
    int num8 = rand.nextInt( 9 ) + 1;
    int num9 = rand.nextInt( 9 ) + 1;
    int num10 = rand.nextInt( 9 ) + 1;
    int [] numbers = {num1, num2, num3, num4, num5, num6, num7, num8, num9, num10};
    ArrayMethodsL8b newArray = new ArrayMethodsL8b(numbers);
    
    System.out.println("STEP 5 - implement me");        
    
    // create an ArrayMethodsL8b object - passing the intNumbersSortedA array as the argument
    System.out.println("--->calling secondary constructor");
    ArrayMethodsL8b arr = new ArrayMethodsL8b(intNumbersSortedA);
    
    // print the content of the array
    System.out.println( "The elements of the array sorted in ascending order are: " + arr.toString());
    
    // print the value of the product calculated  by the method arrayProduct
    System.out.println( "The product of all elements in the array is: "
                         + arr.arrayProduct() );
    // calculate number of swaps
    System.out.println("The number of swaps was " + arr.calculateSwaps()); 
    System.out.println("The array after swaps is: " + arr.toString());
    System.out.println();
    
    // STEP 3    
    // call reverse method
    arr.reverse();
    
    
    // STEP 4
    // print the content of the array
    System.out.println("The reverse is " + arr);
                         
   
    // print the value of the product calculated  by the method arrayProduct
    System.out.println( "The product of all elements in the array is: "
                         + arr.arrayProduct() );
    
    // calculate number of swaps
    System.out.println("The number of swaps was " + arr.calculateSwaps());
    
    
    
    // STEP 6
    // call mutator method to change the array in arr object to the one that contains random numbers
    
    
    
    // STEP 7
    // print the content of the array
    System.out.println( "The elements of the array are: " + newArray.toString());
    
    // print the value of the product calculated  by the method arrayProduct
    System.out.println( "The product of all elements in the array is: "
                         + newArray.arrayProduct() );
    // calculate number of swaps
    System.out.println("The number of swaps was " + newArray.calculateSwaps());
    
    
    // STEP 8
    // prompt the user for a number to search for
    System.out.println( "Enter a number to search for" );
    Scanner scan =  new Scanner( System.in );
    int newNumber = scan.nextInt();
    
    
    // STEP 10
    // call searchForNumber method and print either the position of the 
    // searched for value or not found message
    
    
  }
}
