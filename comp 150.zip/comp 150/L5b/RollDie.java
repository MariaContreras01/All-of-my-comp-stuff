/*  A program that rolls a die and prints it face value
 Anderson, Franceschi
 */

import java.util.Random;

public class RollDie
{
  public static void main( String [] args )
  {
    Random random = new Random( );
    int roll = random.nextInt( 6 ) + 1;
    String face;
    
    switch ( roll )
    {
      case  1:
        face = "One";
        break;
      case  2:
        face = "Two";
        break;
      case  3:
        face = "Three";
        break;
      case  4:    
        face = "Four";
        break;
      case  5:
        face = "Five";
        break;
      case  6:
        face = "Six"; 
        break;
      default:
        face = "unknown";
        break;
    }
    System.out.println("You rolled: " + face);
  }
}
