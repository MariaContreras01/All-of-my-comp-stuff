//Program that tells you your letter grade
//Maria Contreras
// 2-11-15

import java.util.*;

public class TestScore
{
  public static void main ( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter the score you received on a test" );
    int score = scan.nextInt();
    final int MIN_SCORE = 0;
    final int MAX_SCORE = 100;
    
    if ( score < MIN_SCORE || score > MAX_SCORE )
    {
      System.out.println( "Input is invalid" );
    }
    
    else
    {
      char grade;
      score = score/10; 
      
      switch ( score )
      {
        case 0 :
        case 1 :
        case 2 :
        case 3 : 
        case 4 :
        case 5 : 
          grade = 'F';
          break;
        case 6:
          grade = 'D';
          break;
        case 7 :
          grade = 'C';
          break;
        case 8 :
          grade = 'B';
          break;
        case 9 :
        case 10: 
          grade = 'A';
          break;
        default : 
          grade = 'F';
          break;
      }
      
      System.out.println( "Your letter grade is a/an " + grade );
    }
  }
}