//Program that confims a password
//Maria Contreras
// 2-15-15

import java.util.*;

public class WebAdress
{
  public static void main ( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter a web adress" );
    String webAdress = scan.next();
    
    int dot = webAdress.lastIndexOf( "." );
    int length = webAdress.length();
    String ending = webAdress.substring( dot + 1, length );
    String type;
    
    switch ( ending )
    {
      case "gov" :
        type = "government";
        break;
      case "edu" :
        type = "university";
        break;
      case "com" :
        type = "business";
        break;
      case "org" :
        type = "organization";
        break;
      default :
        type = "web adress for another enitiy";
        break;
    }
    
    System.out.println( "It is a/an " + type );
    
  }
}