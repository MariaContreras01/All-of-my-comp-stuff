//Program that tells you if is string is an e-mail
//Maria Contreras
// 2-15-15

import java.util.*;

public class EmailAdress
{
  public static void main ( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter a word." );
    
    String word = scan.next();
    int symbol = word.indexOf( "@" );
    
    if ( symbol >= 0 )
    
    {
      System.out.println( "This word is an e-mail." );
    }
    else
    
    {
      System.out.println( "This word is not an e-mail." );                  
    }
   
  }
}