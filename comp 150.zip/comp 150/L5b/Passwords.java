//Program that confims a password
//Maria Contreras
// 2-15-15

import java.util.*;

public class Passwords
{
  public static void main ( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter your password" );
    String password1 = scan.next();
    
    System.out.println( "Enter your password again" );
    String password2 = scan.next();
    
    int password = password1.compareTo( password2 );
    
    if ( password == 0 )
    
    {
      System.out.println( "You are now registered as a new user" );
    }
    else 
    {
      System.out.println( "Sorry, there is a typo in your password" );
    }
  }
}