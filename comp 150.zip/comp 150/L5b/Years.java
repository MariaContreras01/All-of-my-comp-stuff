//Program that confims a password
//Maria Contreras
// 2-15-15

import java.util.*;

public class Years
{
  public static void main ( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter a year" );
    String year = scan.next();
    int convertYear = Integer.parseInt( year );
    int year2;
    
    Switch ( year )
    {
      case [0-9][0-9] :
        year2 = convertYear + 2000;
        System.out.println( "The year is " + year2 );
        break;
      case [0-9][0-9][0-9][0-9] :
        year2 = convertYear;
        System.out.println( "The year is " + year2 );
        break;
      default :
        System.out.println( "The year entered is not valid" );
        break; 
    }
  }
}