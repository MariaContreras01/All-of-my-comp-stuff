//Program that outputs probable seasons
//Maria Contreras
//2-9-15

import java.util.*;

public class TemperatureSeasons
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter the temperature" );
    
    String season = "";
    int temp = scan.nextInt();
    final int MAX_TEMP = 110;
    final int MIN_TEMP = -5; 
    
    if ( temp > MAX_TEMP || temp < MIN_TEMP )
    
    {
      System.out.println( "The temperature entered is outside valid range" );
    }
    else 
    
    {
      if ( temp >= 90 )
      
      {
        season = "summer";
      }
      else if ( temp >= 70 && temp < 90 )
        
      {
        season = "spring";
      }
      else if ( temp >= 50 && temp < 70 )
      
      {
        season = "fall";
      }
      else
      {
        season = "winter";
      }
      
       System.out.println( "The season is probably " + season );
    }
  }
}