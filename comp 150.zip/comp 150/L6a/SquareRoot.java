//Maria Contreras
//2-23-15

import java.util.*;

public class SquareRoot
{
  public static void main( String [] args )
  {
   
//    1 .with do-while loop keep prompting the user for input for as long as the given number is NOT greater than 10.0 (see example 6.13)
      Scanner scan = new Scanner( System.in );
      final double MAX_NUMBER = 10.0;
      final double MIN_NUMBER = 1.01;
      double number;
      int counter = 0;
      
      do
      {
        System.out.println( "Enter a number greater than 10.0" );
        number = scan.nextDouble();
      }while (!(number > MAX_NUMBER ));


//    2. calculate the first square root of the given number (prime read)
      double squareRoot = Math.sqrt( number );


//    3. with a while loop (see example 6.1):
//         increment the square roots counter
      while ( MIN_NUMBER <= squareRoot )
      {
          counter++;
          System.out.println( "The number of square roots taken is " + counter + " the value is " + squareRoot);
          squareRoot = Math.sqrt( squareRoot );
//         print the running count followed by the square root value
//         calculate the next square root (for example squareRoot = Math.sqrt(squareRoot);)
      }


//    4. print the final results 
      
  }
}