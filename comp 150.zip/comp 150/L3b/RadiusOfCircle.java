//A program that reads the radius of a circle
//Maria Contreras
//3-2-15

import java.util.*;
import java.text.DecimalFormat;

public class RadiusOfCircle
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter the radius of a cricle > " );
    double radius = scan.nextDouble();
    
    DecimalFormat functions = new DecimalFormat( "0.00" );
    double area = Math.PI * Math.pow( radius, 2);
    double perimeter = 2 * Math.PI * radius;
    
    System.out.println( "The area of the circle is " + functions.format(area) + "." +
                        " The perimeter of the circle is " + functions.format(perimeter) + "." );
  }
}
  