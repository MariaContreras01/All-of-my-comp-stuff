// Chapter 3 Programming Activity 2
//   Calling class methods
//   Maria Contreras
//

// ***** 
// 1. add your import statements here
import java.util.*;
import java.text.DecimalFormat;

public class PracticeMethods1
{
  public static void main( String [] args )
  {
    //*****
    // 2.  a. Create a Scanner object to read from the keyboard
    //     b. Prompt the user for his/her first name
    //     c. Print a message that says hello to the user
    //     d. Print a message that says how many letters
    //               are in the user's name
    
    // Your code goes here
    Scanner scan = new Scanner( System.in );
    
    System.out.print( "Enter your first name > " );
    String firstName = scan.next( );
    System.out.println( "Hello, " + firstName ); 
    System.out.println( "There are " + firstName.length( ) + " letters in your name." );
    
    //*****
    // 3.  Print an empty line
    
    // Your code goes here
    System.out.println( );

    
    
    //*****
    // 4.  a. Using previously created Scanner object prompt the user for the year (s)he was born.
    //     b. Calculate and print the age the user will be this year.
    //     c. Declare a constant for average life expectancy,
    //            set its value to 78.74
    //     d. Print a message that tells the user the percentage
    //            of their expected life they've lived.
    //       Use the DecimalFormat class to format the percentage
    
    // Your code goes here
    System.out.print( "Enter the year you were born > " );
    int year = scan.nextInt( );
    int currentYear = 2015;
    int currentAge = currentYear - year;
    System.out.println ( "You will be " + currentAge + " this year." );
    
    DecimalFormat lifeExpectancy =  new DecimalFormat( "#0.0%" );
    final double AVERAGE_LIFE_EXPECTANCY = 78.74;
    double percentageOfLife = currentAge / AVERAGE_LIFE_EXPECTANCY;
    System.out.println( "You have wasted " + lifeExpectancy.format( percentageOfLife ) + 
                       " of your expected life." );
    //*****
    // 5.  a. Create a Random object
    //             and generate a random integer between 1 and 20 inclusive
    //     b. Using previously created Scanner object prompt the user for a guess.
    //     c. Print a message that tells the user the number
    //         and how far from the number the guess was (hint: use Math.abs)
    
    // Your code goes here
    Random random = new Random ( );
    int start = 1;
    int end = 20;
    int number = random.nextInt( end - start + 1 ) + start; 
    
    System.out.print( "I'm thinking of a number between " + start + " and " + end + ". " +
                       "Can you guess the number I'm thinking? > " );
    int guess = scan.nextInt( );
    int difference = Math.abs( number - guess );
    System.out.println( "My number was " + number + " the difference between our numbers " +
                        " is " + difference + "." );
    
  }
}