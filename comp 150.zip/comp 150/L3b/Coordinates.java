//program that reads x and y coordinates 
//Maria Contreras
//3-2-14

import java.awt.Point;
import java.util.*;

public class Coordinates
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter an x coordinate > " );
    int x = scan.nextInt();
    
    System.out.println( "Enter a y coordinate > " );
    int y = scan.nextInt();
    Point point = new Point(x, y);
    System.out.println( "Your coordinates are " + point );
  }
}