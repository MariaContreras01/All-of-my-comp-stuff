//Program that generates five random integers 
//Maria Contreras
//3-2-15

import java.util.*;

public class RandomIntegers
{
  public static void main( String [] args )
  {
    Random random = new Random();
    int start = 60;
    int end = 100;
    int number1 = random.nextInt( end - start + 1 ) + start;
    int number2 = random.nextInt( end - start + 1 ) + start;
    int number3 = random.nextInt( end - start + 1 ) + start;
    int number4 = random.nextInt( end - start + 1 ) + start;
    int number5 = random.nextInt( end - start + 1 ) + start;
    
    int smallest = Math.min( number1, number2 );
    int smallest1 = Math.min( smallest, number3 );
    int smallest2 = Math.min( smallest1, number4 );
    int smallest3 = Math.min( smallest2, number5 );
    System.out.println( "The random numbers are " + number1 + ", " + number2 +
                        ", " + number3 + ", " + number4 + ", " + number5 + "." );
    
    System.out.println( "The smallest number is " + smallest3 + "." );
  }
}