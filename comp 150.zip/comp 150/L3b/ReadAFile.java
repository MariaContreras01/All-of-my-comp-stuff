//Program that reads a file name from a dialog box
//Maria Contreras
// 3-2-1

import java.util.*;

public class ReadAFile 
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    
    System.out.println(" Enter a file name > " );
    String fullFileName = scan.next();
    int dot = fullFileName.indexOf('.');
    int restOfFile = fullFileName.length();
    String fileName = fullFileName.substring( dot, restOfFile);
    System.out.println( "The file extension is " + fileName + "." );
  }
}