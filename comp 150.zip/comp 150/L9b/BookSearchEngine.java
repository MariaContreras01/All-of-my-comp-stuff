/* BookSearchEngine class
 
 */

import java.util.*;

public class BookSearchEngine
{
  public static void main( String [] args )
  {
    BookStore bookStore = new BookStore( );
    System.out.println( "\nOur book collection is:" );
    System.out.println( bookStore );
    
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println( "\nSearching titles, enter a keyword" );
    String keyword = keyboard.next();   
    ArrayList<Book> result = bookStore.searchForTitle( keyword.toLowerCase() );    
    System.out.println( "The search results for \"" + keyword
                         + "\" are:" );
    if (result.size() > 0)
    {
      for( Book tempBook : result )
        System.out.println( tempBook );
    }
    else
    {
      System.out.println("No book meeting your search criteria has been found");
    }
    
    System.out.println( "\nSearching authors, enter a keyword" );
    keyword = keyboard.next();   
    result = bookStore.searchForAuthor( keyword.toLowerCase() );    
    System.out.println( "The search results for \"" + keyword
                         + "\" are:" );
    if (result.size() > 0)
    {
      for( Book tempBook : result )
        System.out.println( tempBook );
    }
    else
    {
      System.out.println("No book meeting your search criteria has been found");
    }
    
    System.out.println( "\nSearching price, enter a keyword" );
    int price = keyboard.nextInt();   
    result = bookStore.searchForPrice( price );    
    System.out.println( "The search results for \"" + price
                         + "\" are:" );
    if (result.size() > 0)
    {
      for( Book tempBook : result )
        System.out.println( tempBook );
    }
    else
    {
      System.out.println("No book meeting your search criteria has been found");
    }
    
    System.out.println("The lowest price is " + bookStore.searchForLowestPrice());
    
  }
}
