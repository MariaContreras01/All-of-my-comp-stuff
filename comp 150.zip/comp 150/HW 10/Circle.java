//Maria Contreras
// 4-21-15

public class Circle extends Shape
{
  private double radius = 0.0;
  
  public Circle( int newRadius )
  {
    setRadius(newRadius);
  }
  
  public double getRadius()
  {
    return radius;
  }
  
  public void setRadius( int newRadius )
  {
    this.radius = newRadius;
  }
  
  public double calculatePerimeter( )
  {
    final double TWO = 2.0;
    double perimeter = TWO * Math.PI * this.radius;
    return perimeter;
  }
  public double calculateArea( )
  {
    double area = Math.PI * Math.pow( this.radius, 2.0);
    return area;
  }
}