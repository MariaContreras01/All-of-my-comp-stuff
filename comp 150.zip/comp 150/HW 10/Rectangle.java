//Maria Contreras
// 4-21-15

public class Rectangle extends Shape
{
  private double width = 0.0;
  private double height = 0.0;
  
  public Rectangle( int newWidth, int newHeight)
  {
    setWidth(newWidth);
    setHeight(newHeight);
  }
  
  public double getWidth()
  {
    return this.width;
  }
  
  public double getHeight()
  {
    return this.height;
  }
  
  public void setWidth( int newWidth )
  {
    this.width = newWidth;
  }
  
  public void setHeight( int newHeight )
  {
    this.width = newHeight;
  }
  
  public double calculatePerimeter( )
  {
    double perimeter = this.width + this.width + this.height + this.height;
    return perimeter;
  }
  public double calculateArea( )
  {
    double area = this.width * this.height;
    return area;
  }
}