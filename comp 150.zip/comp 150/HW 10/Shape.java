//Maria Contreras
//4-21-15

public abstract class Shape
{
  public abstract double calculatePerimeter();
  public abstract double calculateArea();
}