//Maria Contreras
//4-21-15

public class GroceryStore extends Store
{
  private double annualRevenues;
  private boolean chain;
  
  public GroceryStore(String name, double newAnnualRevenues, boolean newChain)
  {
    super(name);
    setAnnualRevenues(newAnnualRevenues);
    setChain(newChain);
  }
  
  public double getAnnualRevenues()
  {
    return annualRevenues;
  }
  
  public boolean getChain()
  {
    return chain;
  }
  
  public void setAnnualRevenues(double newAnnualRevenues)
  {
    this.annualRevenues = newAnnualRevenues;
  }
  
  public void setChain(boolean newChain)
  {
    this.chain = newChain;
  }
  public String toString()
  {
    return super.toString() +
           "annual revenues: " + annualRevenues +
           " chain: " + chain;
  }
    
  public double annualTaxes()
  {
    double annualTax = annualRevenues * SALES_TAX_RATE;
    return annualTax;
  }
}