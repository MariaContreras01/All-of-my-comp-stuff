/* program that encrypts text
 * pass: April1
 * Maria Contreras
 * 4-1-15
 */

import java.util.Random;

public class Cryptogram2
{
//  /*
//   * Instance Variables 
//   */
  private final char [] ALPHABET ={'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', +
                                   'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', +
                                   's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
  private char [] cryptCode;
  private int [] letterCounters;
// 
//  /*
//   * constructor
//   */
public Cryptogram2()
{
   setCryptCode();
   letterCounters[26] = 0;
}
 
 /*
  * Mutator Method 
  */
 public void setCryptCode()
 { 
   Random rand = new Random();
   int pos = rand.nextInt();
   char temp;
   this.cryptCode = new char [ALPHABET.length];
   for ( int i = 0; i < ALPHABET.length; i++ )
   {
     this.cryptCode[i] = ALPHABET[i];
   }
   
   for ( int i = 0; i < this.cryptCode.length; i++ )
   {
     temp = cryptCode[i];
     cryptCode[i] = cryptCode[pos];
     cryptCode[pos] = temp; 
   }
 }
 
 /* 
  * Method that finds letter in ALPHABET
  * returns int
  */
 public int findLetterInAlphabet(int id)
 {
   final int NOT_FOUND = -1;
   int index = NOT_FOUND;
   for ( int i = 0; i < ALPHABET.length && index == NOT_FOUND; i++ )
   {
     if ( ALPHABET[i] == id )
     {
       index = i;
     }
   }
   System.out.println( index );
   return 0; //index;
 }
 
 /*
  * Method that encrypts the string
  * returns String
  */
 public String encrypt( String text )
 {
   String newString;
   for ( int i = 0; i < text.length(); i++ )
   {
     char charText = Character.toLowerCase( text.charAt(i) );
     //int letter = charText.
   }
    
   return "";
 }
 
 /*
  * method that finds letter in the encryption
  * returns int
  */
 public int findLetterInCryptCode(int id)
 {
   final int NOT_FOUND = -1;
   int index = NOT_FOUND;
   for ( int i = 0; i < cryptCode.length && index == NOT_FOUND; i++ )
   {
     if ( cryptCode[i] == id )
     {
       index = i;
     }
   }
   System.out.println( index );
   return 0; //index;
   
 }
 
 /* 
  * method that decrypts the string
  * return String
  */
 public String decrypt()
 {
   return "";
 }
 
 /*
  * Method that shows the frequency of each letter in the file
  */
public void displayStatistics()
{
  
}
 
/*
 * toString method that returns printable content of cryptCode
 * return String
 */
public String toString()
{
  return "";
}
}