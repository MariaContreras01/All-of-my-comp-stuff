/* program that encrypts text
 * pass: April1
 * Maria Contreras
 * 4-1-15
 */

import java.util.Random;
import java.text.DecimalFormat;

public class Cryptogram
{
  /*
   * Instance Variables 
   */
  private final char [] ALPHABET ={'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', +
                                   'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', +
                                   's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
  private char [] cryptCode;
  private int [] letterCounters;
 
  /*
   * constructor
   */
  public Cryptogram()
  {
    setCryptCode();
    letterCounters = new int [26];
  }
  
  /*
   * Mutator Method 
   */
  public void setCryptCode()
  { 
    Random rand = new Random();
    int pos = rand.nextInt(26);
    char temp;
    this.cryptCode = new char [ALPHABET.length];
    for ( int i = 0; i < ALPHABET.length; i++ )
    {
      this.cryptCode[i] = ALPHABET[i];
    }
    
    for ( int i = 0; i < this.cryptCode.length; i++ )
    {
      temp = this.cryptCode[i];
      this.cryptCode[i] = this.cryptCode[pos];
      this.cryptCode[pos] = temp; 
    }
    
  }
  
  /* 
   * Method that finds letter in ALPHABET
   * returns int
   */
  public int findLetterInAlphabet(int id)
  {
    final int NOT_FOUND = -1;
    int index = NOT_FOUND;
    for ( int i = 0; i < ALPHABET.length && index == NOT_FOUND; i++ )
    {
      if ( ALPHABET[i] == id )
      {
        index = i;
      }
    }
    return index;
  }
  
  /*
   * Method that encrypts the string
   * returns String
   */
  public String encrypt( String text )
  {
    String newString = "";
    String finalString = "";
    for ( int i = 0; i < text.length(); i++ )
    {
      char charText = Character.toLowerCase( text.charAt(i) );
      int letter = findLetterInAlphabet(charText);
      if ( letter > -1 )
      {
       newString = Character.toString(this.cryptCode[letter]);
       this.letterCounters[letter]++;
      }
      else 
      {
        newString = Character.toString(charText);
      }
      finalString += newString;
    }
    
    return finalString;
  }
  
  /*
   * method that finds letter in the encryption
   * returns int
   */
  public int findLetterInCryptCode(int id)
  {
    final int NOT_FOUND = -1;
    int index = NOT_FOUND;
    for ( int i = 0; i < this.cryptCode.length && index == NOT_FOUND; i++ )
    {
      if ( this.cryptCode[i] == id )
      {
        index = i;
      }
    }
    return index; 
  }
  
  /* 
   * method that decrypts the string
   * return String
   */
  public String decrypt(String encryptedPhrase)
  {
    String newString = "";
    String finalString = "";
    for ( int i = 0; i < encryptedPhrase.length(); i++ )
    {
      char charPhrase = Character.toLowerCase( encryptedPhrase.charAt(i) );
      int letter = findLetterInCryptCode( charPhrase );
      if (letter > -1 )
      {
       newString = Character.toString(this.ALPHABET[letter]);
      }
      else 
      {
        newString = Character.toString(charPhrase);
      }
      finalString += newString;
    }
    return finalString;
  }
  
  /*
   * Method that shows the frequency of each letter in the file
   */
  public void displayStatistics()
  {
    for ( int i = 0; i < this.letterCounters.length; i++ )
    {
      DecimalFormat precentPattern = new DecimalFormat( "#0.0%" );
      int number = this.letterCounters[i];
      int total = 1;
      int frequency = ( number / total);
      System.out.println( ( i + 1 ) + " -> " + this.letterCounters[i] + " -> " );
    }
  }
  
  /*
   * toString method that returns printable content of cryptCode
   * return String
   */
  public String toString()
  {
    return "Alphabet:" + this.ALPHABET +
           "\nCryptCode:" + this.cryptCode;
  }
}