//Maria Contreras
//4-22-15

import java.text.DecimalFormat;

public class StudentRecord
{
  public static final DecimalFormat GPA = new DecimalFormat("#0.00");
  private String name;
  private String id;
  private String password;
  private double gpa;
  
  public StudentRecord(String setName,
                       String setId,
                       String setPassword,
                       double setGpa)
  {
    this.name = setName;
    this.id = setId;
    this.password = setPassword;
    this.gpa = setGpa;
  }
  
  public String toString()
  {
    return "Name: " + this.name +
           "ID: " + this.id +
           "Password: " + this.password + 
           "GPA: " + GPA.format(gpa);
  }
}