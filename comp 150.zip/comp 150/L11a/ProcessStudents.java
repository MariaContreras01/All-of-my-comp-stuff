//Maria Contreras
//4-22-15

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.ArrayList;

public class ProcessStudents
{
  public static void main( String [] args )
  {
    ArrayList<StudentRecord> listStudentRecords = new ArrayList<StudentRecord>();
    
    try
    {
      Scanner file = new Scanner( new File("studentsInput.txt") );
      while ( file.hasNext() )
      {
        String stringRead = file.nextLine();
        Scanner parse = new Scanner( stringRead );
        parse.useDelimiter("&");
        String name = parse.next();
        String id = parse.next();
        String password = parse.next();
        
        try 
        {
          double gpa = parse.nextDouble();
          
          StudentRecord srTemp = new StudentRecord( name, id, password, gpa );
          listStudentRecords.add( srTemp );
        }
        
        catch ( InputMismatchException ime )
        {
          System.out.println( "Error in student record" );
        } 
        
      }
      
      file.close();
    }
    
      catch ( FileNotFoundException fnfe )
      {
        System.out.println( "Unable to find studentsInput.txt" );
      }
      
      catch ( IOException ioe )
      {
        ioe.printStackTrace();
      }
    for ( StudentRecord student: listStudentRecords )
    {
      try 
      {
        FileOutputStream fos = new FileOutputStream( "studentOutput.txt", false);
        
        PrintWriter pw = new PrintWriter( fos );
      
        pw.print( student );
      
        pw.close();
      }
      
      catch ( FileNotFoundException fnfe )
      {
        System.out.println("unable to find studentOutput.txt");
      }
    }
  }
}