//Maria Contreras
//4-29-15

public abstract class Card
{
  //instant variable
  private char face;
  
  public Card(char newFace) //constructor 
  {
    face = newFace;
  }
  
  public char getFace() //gets face of the card
  {
    return this.face; 
  }
  
  public String toString()
  {
    return " " + this.face; 
  }
  
  public abstract int getPoints();
 
}