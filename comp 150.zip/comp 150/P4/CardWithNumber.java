//Maria Contreras
//4-29-15

public class CardWithNumber extends Card
{
  public CardWithNumber(char newCard)
  {
    super(newCard);
  }
  
  public int getPoints() //calculates points for cards with a number
  {
    return 0; 
  }
}