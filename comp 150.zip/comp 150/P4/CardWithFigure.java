//Maria Contreras
//4-29-15

public class CardWithFigure extends Card
{
  //instant vairiable 
  public final static String MAPPING = "TJQKA";
  
  public CardWithFigure(char newCard)
  {
    super(newCard);
  }
  
  public int getPoints() //calculates oints for a card with a figure 
  {
    return MAPPING.indexOf(getFace());
  }
}