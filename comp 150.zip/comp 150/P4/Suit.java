//Maria Contreras
//4-29-15

import java.util.*;

public class Suit
{
  //instant variables
  private ArrayList<Card> cards;
  private String suitStr;
  private final int MIN_LONG = 5;
  private final int VOID_POINTS = 3;
  private final int SINGLETON_POINTS = 2;
  private final int DOUBLETON_POINTS = 1;
  
  public Suit(String newSuit)
  {
    this.cards = new ArrayList<Card>();
    this.suitStr = newSuit;
  }
  
  public void addCard(char newChar)
  {
    if( CardWithFigure.MAPPING.indexOf(newChar) > 0)
    {
      CardWithFigure card = new CardWithFigure(newChar); // card object
      this.cards.add(card); // adds card object to ArrayList of cards 
    }
    
    else 
    {
      CardWithNumber temp = new CardWithNumber(newChar);
      this.cards.add(temp);
    }
  }
  
  //method that prints all the cards in the string
  public void printSuit() 
  {
    if ( this.cards.size() != 0) //checks to see if the cards are not 0
    {
      System.out.print( this.suitStr + ":" + "\t"); //formats
      for ( int i = 0; i < this.cards.size(); i++ ) //reads the cards
      {
        System.out.print( this.cards.get(i) + " " ); //prints the cards 
      }
      System.out.println(); //prints new line
    }
  }
  
  //calculates the points for the suit
  public int suitPoints()
  { 
    int points = 0; //variable for points
    
    if ( this.cards.size() > MIN_LONG ) //checks to see if the suit is a min long
    {
      points = cards.size() - MIN_LONG; //calculates points
    }
    else if ( this.cards.size() == 0 ) //adds 3 points if points if suit is a void
    {
      points += VOID_POINTS;
    }
    
    else if ( this.cards.size() == 1 ) //adds 2 points if suit is singleton
    {
      points += SINGLETON_POINTS;
    }
    
    else if ( this.cards.size() == 2 ) //adds 1 point if the suit is a doubleton
    {
      points += DOUBLETON_POINTS;
    }
    
      for ( int i = 0; i < this.cards.size(); i++ ) //reads cards
      {
        points += this.cards.get(i).getPoints(); //adds points
        //System.out.println( points );
      }       
    return points; 
  } 
}