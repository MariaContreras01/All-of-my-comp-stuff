//Maria Contreras
//4-29-25

import java.util.*;

public class Bridge
{
  private final String [] SUIT_STRINGS = { "Clubs", "Diamonds", "Hearts", "Spades" };
  private final String SUIT_CHARS = "CDHS";
  private Suit [] hand;
  
  public Bridge(String newString )
  {
    
    this.hand = new Suit[4];
    for ( int i = 0; i < SUIT_STRINGS.length; i++ )
    {
      this.hand[i] = new Suit(SUIT_STRINGS[i]);
    }
    Scanner parse = new Scanner( newString );
    
    char face = ' ';
    while ( parse.hasNext() )
    {
      String temp = parse.next();
       
      if (temp.charAt(1) == this.SUIT_CHARS.charAt(0))
      {
        face = temp.charAt(0);
        this.hand[0].addCard(face);
      }
       
      else if (temp.charAt(1) == this.SUIT_CHARS.charAt(1))
      {
        face = temp.charAt(0);
        this.hand[1].addCard(face);
      }
       
      else if ( temp.charAt(1) == this.SUIT_CHARS.charAt(2))
      {
        face = temp.charAt(0);
        this.hand[2].addCard(face);
      }
       
      else 
      {
        face = temp.charAt(0);
        this.hand[3].addCard(face);
      } 
    }
  }
  
  public void printHand()
  {
    for ( int i = 0; i < hand.length; i++ )
    {
      hand[i].printSuit();
    }
  }
  
  public void printTotalPoints()
  {
    int total = 0;
    for (int i = 0; i < hand.length; i++ )
    {
      total += this.hand[i].suitPoints();
    }
    System.out.printf("Total Points: " + total );
  }
}