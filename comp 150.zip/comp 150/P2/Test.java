
import java.util.Scanner;
public class Test
{
  public static void main( String [] args )
  {
Scanner scan = new Scanner( System.in );
System.out.println( "input" );
int checkSum = scan.nextInt();

int counter = 0;
    while( checkSum % 10 != 0 )
    {
      checkSum++;
      counter++;
    }
    System.out.println( counter );
  }
 }
