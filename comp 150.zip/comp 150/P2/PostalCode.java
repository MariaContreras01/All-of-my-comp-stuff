/**
 * SERVICE CLASS Translate ZIP code into its bar code representation
 * 
 * @author Anna Bieszczad
 * @version 03/03/2015
 */
public class PostalCode 
{
  /**
   * Instance variable. <BR>
   * Contains the zipCode in a DDDDD-DDDD format
   * (for example 12345-6789)
   */
  private String zipCode;
  private String barCode;
  
  /**
   * Secondary constructor.<BR>
   * Allows user to provide the value of the zipCode
   * 
   * @param zipCode initial value of the zipCode
   */
  public PostalCode(String zipCode) 
  {
    setZipCode(zipCode);
  }
  
  /**
   * Mutator method.<BR> 
   * Sets the value of a zipCode to the given new value
   * and sets the barCode to the bar code representation of the zipCode
   * 
   * @param zipCode
   */
  public void setZipCode(String zipCode) 
  {
    this.zipCode = zipCode;
    setBarCode();
  }
  
  /**
   * private mutator method that converts the zipCode into the bar code format 
   * and sas it in a barCode instance variable.
   */
  private void setBarCode() 
  {    
    // IMPLEMENT THIS METHOD
    
    // 1. first remove all '-' for easy processing
    String zipStr = zipCode.replaceAll( "[ -]", "" );
    System.out.println( "zipString is " + zipStr );

    // 2. calculate the checksum by calling the private calculateChecksum method
    int checkSum = calculateChecksum( zipStr );
    System.out.println( "checkSum is " + checkSum );
    // 3. calculate the check digit by calling the private calculateCheckDigit method
    int checkDigit = calculateCheckDigit( checkSum );
    System.out.println( "checkDigit is " + checkDigit );
    // 4. append the check digit to the zip string for final processing
    String checkDigitString = Integer.toString(checkDigit);
    String zipStr2 = zipStr + checkDigitString;
    System.out.println( "The zip code with the appended check digit is " + zipStr2 );
    
    // 5. produce the bar code and save it in barCode instance variable
    //    use a for loop and a switch inside the loop
    for ( int i = 0; i < zipStr.length(); i++ )
    {
      switch ( zipStr2.charAt(i) )
      {
        case '1':
        barCode+= ":::|||";
        break;
        
        case '2':
        barCode+= "::|:|";
        break;
        
        case '3':
        barCode+= "::||:";
        break;
        
        case '4':
        barCode+= ":|::|";
        break;
        
        case '5':
        barCode+= ":|:|:";
        break;
        
        case '6':
        barCode+= ":||::";
        break;
        
        case '7':
        barCode+= "|:::|";
        break;
        
        case '8':
        barCode+= "|::|:";
        break;
        
        case '9':
        barCode+= "|:|::";
        break;
        
        case '0':
        barCode+= "||:::";
        break;  
      }
    }
  }
  
  /**
   * Business method that calculates the checksum for the given zipCode.
   * 
   * @param zipStr the zipCode without spaces and '-'
   * @return checkSum
   */
  
  private int calculateChecksum(String zipStr) 
  {
    
    // IMPLEMENT THIS METHOD
    // HINT: to get the numberic value of each character
    //       utilize Character.digit(zipStr.charAt(i),10) method inside 
    //       a for loop which runs over zipStr string 
    int numericValue = 0;
    int zipInt = 0;
    for ( int i = 0; i < zipStr.length(); i++ )
    {
      zipInt = Character.digit(zipStr.charAt(i), 10);
      numericValue+=zipInt;
    }

    return numericValue; // <-- this is a stub added for compilation
  }
  
  /**
   * Business method that calculates the check digit.
   * 
   * @param checkSum sum of the zipCode digits
   * @return check digit
   */
  private int calculateCheckDigit(int checkSum) 
  {

    // IMPLEMENT THIS METHOD
    int counter = 0;
    while( checkSum % 10 != 0 )
    {
      checkSum++;
      counter++;
    }
    
    return counter; // <-- this is a stub added for compilation
  }
  
  
  /**
   * Accessor method.
   * 
   * @return the instance variable barCode
   */
  public String getBarCode() 
  {
    return this.barCode;
  }
  
  /**
   * Accessor method.
   * 
   * @return the instance variable zipCode
   */
  public String getZipCode() 
  {
    return this.zipCode;
  }
  
   /**
   * toString method.
   * 
   * @return the string representation of the PostalCode object
   */
  public String toString()
  {
    return "The zip code: " + this.zipCode + " has the following bar code: " + this.barCode;
  }
}