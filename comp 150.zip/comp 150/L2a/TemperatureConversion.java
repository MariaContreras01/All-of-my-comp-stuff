// Temperature Conversion
// your name
//

public class TemperatureConversion
{
   public static void main( String [] args )
   {
      //***** 1. declare any constants here, FREEZING_POINT would be a good candidate
       private int FREEZING_POINT = 32;
	
			
      //***** 2.  declare temperature in Fahrenheit as an int 
       int temp = 58;
	  		
      //***** 3. calculate equivalent Celsius temperature	
	  
        int celsius = 5 / 9 * (temp - FREEZING_POINT)
      //***** 4. output the temperature in Celsius
	   system.out.println() = celsius
												  
      //***** 5. convert Celsius temperature back to Fahrenheit
		
         int fahernheit = (9 / 5) * ( celsius + 32)
      //***** 6. output Fahrenheit temperature to check correctness 
		system.out.println() = fahernheit 
				
   }
} 