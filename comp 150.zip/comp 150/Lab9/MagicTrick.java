/**
 * Service class with supporting methods for Magic Trick
 *
 * @author Maria Contreras
 * @version 10/30/2013
 */

import java.util.*;

public class MagicTrick
{
    private int[][] grid;
    private int flippedRow;
    private int flippedCol;
    public static final int GRID_SIZE = 6;

    /**
     * default constructor,
     * sets elements in the grid to randomly generated either 0 or 1
     * calls setParity method
     */
    public MagicTrick()
    {
      this.grid = new int[GRID_SIZE][GRID_SIZE];
      Random rand = new Random();
      for ( int r = 0; r < this.grid.length-1; r++ )
      {
        for ( int c = 0; c < this.grid[r].length-1; c++ )
        {
          this.grid[r][c]=rand.nextInt(2);
        }
        
      }
      
      setParity();
      // see Lab9a Notes
    }
    
     /**
     * sets elements in the last row and the last column
     * to either 1 or 0, so the sum of the elements in the appropriate row and column is even
     *
     */
    public void setParity()
    {
      final int TWO = 2;
      for ( int r = 0; r < this.grid.length-1; r++ )
      {
        int sum = 0;
        for( int c = 0; c < this.grid.length-1; c++ )
        {
          sum+=grid[r][c];
        }
        
        if ( sum % TWO != 0 )
        {
          this.grid[r][this.grid[r].length-1] = 1;
        }
        else
        {
          this.grid[r][this.grid[r].length-1] = 0;
        }
      }
      
      int maxNumberOfColumns = 6;
      for ( int c = 0; c < maxNumberOfColumns; c++ )
      {
        int sum = 0;
        for ( int r = 0; r < this.grid.length-1; r++ )
        {
          if ( c < grid[r].length )
          {
            sum+=this.grid[r][c];
          }
        }
         
        if ( sum % TWO != 0 )
        {
          this.grid[this.grid[c].length-1][c] = 1;
        }
        else 
        {
          this.grid[this.grid[c].length-1][c] = 0;
        }
      }
      // See Lab9a Notes   
    }
    
     /**
     * flips the value of the randomly
     * selected element
     */
    public void flipOneElement()
    {
      Random rand = new Random();
      flippedRow = rand.nextInt(5)+1;
      flippedCol = rand.nextInt(5)+1;
      if ( grid[flippedRow][flippedCol] == 0 )
      {
        grid[flippedRow][flippedCol] = 1;
      }
      else
      {
        grid[flippedRow][flippedCol] = 0;
      }
      // See Lab9a Notes
      
    }

    /**
     * accessor method
     * @return  the value of the row of the flipped element: this.flippedRow
     */
    public int getFlippedRow()
    {
        return flippedRow; // THIS IS A STUB
    }

    /**
     * accessor method
     * @return  the value of the column of the flipped element: this.flippedCol
     */
    public int getFlippedColumn()
    {
        return flippedCol; // THIS IS A STUB
    }

    /**
     * toString method returns printable version
     * of the content of this.grid
     */
    public String toString()
    {
        String returnValue = "";
        for (int r = 0; r < GRID_SIZE; r++)
        {
            for (int c = 0; c < GRID_SIZE; c++)
            {
                returnValue += this.grid[r][c] + " ";
            }
            returnValue += "\n";
        }
        return returnValue += "\n";
    }




    /**
     * scheck the users guess
     * 
     * @param r - the row selected by the user
     * @param c - the column selected by the user
     * @return - true if the guessed row and column are the same
     *                as the row and column of the flipped element
     */
    public boolean checkGuess(int r, int c)
    {
      boolean check = false;
      if ( r == flippedRow && c == flippedCol )
      {
        check = true;
      }
        return check;  // THIS IS A STUB
    }
}