/* Course class
   Maria Contreras
*/

public class Course
{
  private String code;
  private String description;
  private int numberOfCredits;
  
  public Course( )
  {
    this.code = "unknown";
    this.description = "unknown";
    this.numberOfCredits = 0;
  }
  
  public Course( String model, String description, int numberOfCredits )
  {
    this.code = code;
    this.description = description;
    this.numberOfCredits = numberOfCredits;
  }
  
  public String getCode( )
  {
    return this.code;
  }
  
  public String getDescription( )
  {
    return this.description;
  }
                               
  public int getNumberOfCredits( )
  {
    return this.numberOfCredits;
  }
  
  public void setCode( String code )
  {
    this.code = code;
  }
  
  public void setDescription( String description )
  {
    this.description = description;
  }
  
  public void setNumberOfCredits( )
  {
    if ( numberOfCredits >=  0 )
       this.numberOfCredits = numberOfCredits;
     else
     {
       System.err.println( "number of credits must be at least 0" );
       System.err.println( "Value of credits unchanged." );
     }
  }
  
  public String toString( )
  {
    return "Code: " + code +
           " \n Description: " + description +
           "\n Number of credits: " + numberOfCredits;
  }
  
  public boolean equals( Course other ) 
  {
    return this.code.equals( other.code ) 
      && this.description.equals( other.description )
      && this.numberOfCredits == other.numberOfCredits;
  }
  
  public int level( )
  {
    int courseCode = 0;
    switch ( code )
    {
      case "CS1":
      courseCode = 1;
      break;
      
      case "CS2":
      courseCode = 2;
      break;
      
      case "CS3":
      courseCode = 3;
      break;
      
      case "CS4":
      courseCode = 4;
      break;
    }
    
    return courseCode;
  }
}