/* A client program to display Course object values
   Maria Contreras
*/

public class CourseClient 
{
  public static void main( String [] args )
  {
    Course course = new Course();
  }
}