/* TelevisionChannel class
   Maria Contreras
*/

public class TelevisionChannel
{
  private String name;
  private int number;
  private boolean cable;
  
  public TelevisionChannel()
  {
    name = "";    
    number = 0;
    cable = false; 
  }
  
  public TelevisionChannel( String startName, int startNumber, boolean startCable )
  {
    setName( startName );
    setNumber( startNumber );
    setCable( startCable );
  }
  
  public String getName()
  {
    return name;
  }
  
  public int getNumber()
  {
    return number;
  }
  
  public boolean getCable()
  {
    return cable;
  }
  
  public void setName( String newName )
  {
    name = newName;
  }
  
  public void setNumber( int newNumber )
  {
    if ( newNumber >= 0 )
      number = newNumber;
    else
    {
      System.err.println( "Number cannot be negative" );
      System.err.println( "Value not changed" );
    }
  }
  
  public void setCable( boolean newCable ) 
  {
    cable = newCable;
  }
  
  public int numberOfDigitsChannel()
  {
    int numberOfDigits;
    String numberString;
    numberString = Integer.toString( number );
    numberOfDigits = numberString.length();
    return numberOfDigits; 
  }
}