/* TelevisionChannel class
   Maria Contreras
*/

public class TelevisionChannelPart2
{
  private String name;
  private int number;
  private boolean cable;
  private int numberOfDigits;
  
  public TelevisionChannelPart2()
  {
    name = "";    
    number = 0;
    cable = false; 
  }
  
  public TelevisionChannelPart2( String startName, int startNumber, boolean startCable )
  {
    setName( startName );
    setNumber( startNumber );
    setCable( startCable );
  }
  
  public String getName()
  {
    return name;
  }
  
  public int getNumber()
  {
    return number;
  }
  
  public boolean getCable()
  {
    return cable;
  }
  
  public void setName( String newName )
  {
    name = newName;
  }
  
  public void setNumber( int newNumber )
  {
    if ( newNumber >= 0 )
      number = newNumber;
    else
    {
      System.err.println( "Number cannot be negative" );
      System.err.println( "Value not changed" );
    }
  }
  
  public void setCable( boolean newCable ) 
  {
    cable = newCable;
  }
  
  public int numberOfDigitsChannel()
  {
    String numberString;
    numberString = Integer.toString( number );
    numberOfDigits = numberString.length();
    return numberOfDigits; 
  }
  
  public String toString()
  {
    return "Name: " + name + 
           "\n Number: " + number + 
           "\n Cable: " + cable +
           "\n Number of digits: " + numberOfDigits;
  }
  
  public boolean equals( TelevisionChannelPart2 other )
  {
    return this.name.equals( other.name )
      && this.number == other.number
      && this.cable == other.cable;
  }
  
  
}