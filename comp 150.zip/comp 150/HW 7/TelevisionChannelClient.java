/* A client program to display TelevisionChannel object values
   Maria Contreras
*/

public class TelevisionChannelClient
{
  public static void main( String [] args )
  {
    TelevisionChannel tvChannel = new TelevisionChannel();
  }
}