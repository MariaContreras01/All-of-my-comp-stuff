/* A client program to display TelevisionChannelPart2 object values
   Maria Contreras
*/

public class TelevisionChannelClient2
{
  public static void main( String [] args )
  {
    TelevisionChannelPart2 tvChannel = new TelevisionChannelPart2();
  }
}