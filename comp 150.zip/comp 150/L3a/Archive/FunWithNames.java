//a program to display java strings 
//Maria Contreras
//2-1-15

public class FunWithNames
{
  public static void main( String [] args )
  {
    String myFullName = "Maria Contreras";
    System.out.println( "My name in uppercase is " + myFullName.toUpperCase( ) +
                        ". " + "My name in lowercase is " + myFullName.toLowerCase( ) +
                        ". My name is " + myFullName + "." );
    
    System.out.println( "My name is " + myFullName.length( ) + " characters long." );
    
    String myFirstName = myFullName.substring( 0, 5 );
    String myLastName = myFullName.substring( 6, 15 );
    System.out.println( "My inverted name is " + myLastName + ", " +
                         myFirstName + "." );
    
    String friendsFullName = "Rivers Cuomo";
    System.out.println( "My friend's name is " + friendsFullName + " and it is " +
                         friendsFullName.length() + " characters long." );
                       
    String friendsFirstName = friendsFullName.substring( 0, 6 );
    String friendsLastName = friendsFullName.substring( 7, 12);
    System.out.println( "My friend's inverted name is " + friendsLastName + ", " +
                         friendsFirstName + "." );
    
    //I tried running it like this: 
    //System.out.print( myFirstName.charAt(0) + myLastName.charAt( 0 ) + " and " +
                      //friendsFirstName.charAt( 0 ) + friendsLastName.charAt( 0 ) +
                      //" are friends." ); 
    //Instead of displaying my initials it diplayed the number 144.
    //The only way I could get it to work was by writing it like this:
    //myFirstName.charAt(0) + "" +  myLastName.charAt( 0 )
    System.out.print( myFirstName.charAt(0) + "" + myLastName.charAt( 0 ) + " and " +
                      friendsFirstName.charAt( 0 ) + friendsLastName.charAt( 0 ) +
                      " are friends." );

  }
}