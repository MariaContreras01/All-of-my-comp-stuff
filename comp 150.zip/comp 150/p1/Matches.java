//program that validates a sentence
// Maria Contreras
// 2-17-15

import java.util.*;

public class Matches
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Please enter a sentence that consists of " +
                        "letters only and ends with a period, an " +
                        "exclamation mark, or a question mark. " );
    String sentence = scan.nextLine();
    String valid;
    final String SENTENCE_PATTERN = "[a-z A-Z]*[.!?]";
    
    if ( sentence.matches(SENTENCE_PATTERN) )
    {
      valid = sentence.replaceAll("[aeiou]", "@");
      System.out.println( "The entered sentence " + sentence +
                        " with all vowels replaced is " + valid );
    }
    
    else
    {
      System.out.println( "Sentence entered is not valid" );
     }
  }
}