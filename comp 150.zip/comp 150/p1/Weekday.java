//implements algorithim that calculates day of the week you were born on
//Maria Contreras
// 2-16-15

import java.util.*;

public class Weekday
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter birth year as an int" );
    int bYear = scan.nextInt();
    
    System.out.println( "Enter birth day as an int" );
    int bDay = scan.nextInt();
    
    System.out.println( "Enter birth month as a string" );
    String bMonth = scan.next();
    
    int intMonth;
    
//1. Take the two last digits of the year and divide them by 12: 32 / 12 = 2 (rest: 8) If it's a number smaller than 12 it would like this: 07 / 12 = 0 (rest: 7).
    int quotient = ( bYear % 100 ) / 12;
    int rest = ( bYear % 100 ) % 12;

//2. Add the rest of the division in step 1 to the quotient: 2 + 8 = 10.
    int sum = quotient + rest;
    
    
//3. Divide the rest in step 1 by 4: 8 / 4 = 2. If there's a rest, just omit it.
    int quotient2 = rest / 4;
    
//4. Add the quotient in step 3 to the sum in step 2: 10 + 2 = 12.
    int sum2 = quotient2 + sum;
    
//5. Add the day of the month to the sum in step 4: 12 + 27 = 39.
    int sum3 = sum2 + bDay;
    
//6. Now have a look at the following list. Add the month's number to the sum in step 5, in this case: 39 + 1 = 40.
    switch ( bMonth )
    {
      case "January" :
      sum3 = sum3 + 1;
      intMonth = 1;
      break;
      
      case "February" :
      sum3 = sum3 + 4;
      intMonth = 2;
      break;
      
      case "March" :
      sum3 = sum3 + 4;
      intMonth = 3;
      break;
     
      case "April" :
      sum3 = sum3 + 0;
      intMonth = 4;
      break;
      
      case "May":
      sum3 = sum3 + 2;
      intMonth = 5;
      break;
    
      case "June" :
      sum3 = sum3 + 5;
      intMonth = 6;
      break;
    
      case "July" :
      sum3 = sum3 + 0;
      intMonth = 7;
      break;
    
      case "August" :
      sum3 = sum3 + 3;
      intMonth = 8;
      break;
      
      case "September" :
      sum3 = sum3 + 6;
      intMonth = 9;
      break;
     
      case "October" :
      sum3 = sum3 + 1;
      intMonth = 10;
      break;
    
      case "November" :
      sum3 = sum3 + 4;
      intMonth = 11;
      break;
     
      case "December" :
      sum3 = sum3 + 0;
      intMonth = 12;
      break;
      
      default : 
      intMonth = 0;
      break; 
    }
    
    if ( bYear % 4 == 0 && bYear % 100 > 0 || bYear % 400 == 0)
    {
      if ( bMonth.equals( "January" ) || bMonth.equals( "February" ) )
      {
        sum3 = sum3 - 1;
      }
    }
//a) Heads up! If the year is a leap year and the month is a January or a February, you have to subtract 1 from the month's number yet.  1832 has been a leap year and the month is a January, so: 40 - 1 = 39.
//A year is a leap year if it is: divisible by 4 but not divisible by 100, or divisible by 400
//For example, the years 2000 and 2008 were leap years, but 2099 and 3000 will not be.
//7. If the year is 2000 or later, you subtract 1. If it's a year in the 19th century (as in this case), you add 2: 39 + 2 = 41.
    if ( bYear >= 2000 )
    {
      sum3 = sum3 - 1;
    }
    
    else if ( bYear < 1899 )
    {
      sum3 = sum3 + 2;
    }
//8. Divide the sum in step 7 by 7: 41 / 7 = 5 (rest: 6). The rest tells you the weekday: 0 = Saturday, 1 = Sunday, 2 = Monday, 3 = Tuesday, 4 = Wednesday, 5 = Thursday, 6 = Friday.
     int weekday = sum3 % 7;
//9. Display the result
     System.out.println ( weekday );
//10. Create GregorianCalendar object of the same date and check if the weekday calculated by your program is the same as the weekday returned by the GregorianCalendar object. Display appropriate message.
     GregorianCalendar birthWeekday = new GregorianCalendar(bYear, intMonth, bDay);
     
     System.out.println( "I calculated that " + bMonth + " " + bDay + ", " + bYear +
                         " Falls on " + weekday);
 
  }
}