//Program that takes the x and y points o a cartesian plane
//Maria Contreras
//2-17-15

import java.util.*;

public class CartesianPlane
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );
    System.out.println( "Enter the value of x" );
    double x = scan.nextDouble();
    
    System.out.println( "Enter the value of y" );
    double y = scan.nextDouble();
    
    double x1 = 0;
    double y1 = 0;
    
    double distance = Math.sqrt( (Math.pow( (x-x1), 2)) + (Math.pow( (y-y1), 2)) );
    
    if ( x == 0 )
    {
      System.out.println( "points are on the y-axis" );
    }
    
    else if ( y == 0 )
    {
      System.out.println( "points are on the x-axis" );
    }
    
    else if ( x > 0 && y > 0)
    {
      System.out.println( "The points ( " + x + ", " + y + " ) lie in the first quadrant. " +
                          "The distance between those points and ( 0, 0 ) is " + distance );
    }
    
    else if ( x < 0 && y > 0)
    {
      System.out.println( "The points ( " + x + ", " + y + " ) lie in the second quadrant. " +
                          "The distance between those points and ( 0, 0 ) is " + distance );
    }
    
    else if ( x < 0 && y < 0)
    {
      System.out.println( "The points ( " + x + ", " + y + " ) lie in the third quadrant. " +
                          "The distance between those points and ( 0, 0 ) is " + distance );
    }
    
    else 
    {
      System.out.println( "The points ( " + x + ", " + y + " ) lie in the fourth quadrant. " +
                          "The distance between those points and ( 0, 0 ) is " + distance );
    }
  }
}