//method that returns the average of the elements in an array
//Maria Contreras
//April 12, 2015

import java.util.*;

public class AverageOfElements
{
  private int [][] arr;
  private final int SIZE = 4;
  private int sum;
  private int sum2;
  private int average;

  public AverageOfElements()
  {
    this.arr = new int[SIZE][SIZE];
    Random rand = new Random();
      for ( int r = 0; r < this.arr.length; r++ )
      {
        for ( int c = 0; c < this.arr[r].length; c++ )
        {
          this.arr[r][c]=rand.nextInt(5);
        }
        
      }
  }
  
  public int calculateAverage()
  { 
    for ( int r = 0; r < this.arr.length; r++ )
      {
        for ( int c = 0; c < this.arr[r].length; c++ )
        {
          sum+= this.arr[r][c];
          sum2+=1;
          average = sum/sum2;
        }
      }
    return average;
  }
  
    
  
   public String toString()
    {
        String returnValue = "";
        for (int r = 0; r < SIZE; r++)
        {
            for (int c = 0; c < SIZE; c++)
            {
                returnValue += this.arr[r][c] + " ";
            }
            returnValue += "\n";
        }
        return returnValue += "\n";
    }
 }