//clien class for SumOfElements
//Maria Contreras
//4-12-15

public class SumOfElementsClient
{
  public static void main( String [] args )
  {
    SumOfElements arr1 = new SumOfElements();
    System.out.println( arr1 +
                        "\nThe sum of the last column in each row is " + arr1.addColumns());
  }
}