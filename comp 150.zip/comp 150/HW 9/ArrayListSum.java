//method that returns the sum of all elements in an ArrayList of integers
//Maria Contreras
//4-12-15

import java.util.*;
public class ArrayListSum
{
  public ArrayList<Integer> listOfInts;
  public int sum;
  
  public ArrayListSum( )
  {
    Random rand = new Random();
    this.listOfInts = new ArrayList<Integer>( );
    this.listOfInts.add(new Integer(rand.nextInt(5)));
    this.listOfInts.add(new Integer(rand.nextInt(5)));
    this.listOfInts.add(new Integer(rand.nextInt(5)));
    this.listOfInts.add(new Integer(rand.nextInt(5)));
    this.listOfInts.trimToSize( );
  }
  
  public String toString( )
  {
    String result = "";
    for( Integer tempInt : this.listOfInts )
    {
      result += tempInt.toString( ) + "\n";
    }
    return result;
  }
  
  public Integer addInts()
  {
    for ( Integer currentInt : listOfInts )
    {
      sum += currentInt;
    }
    return sum;
  }
}