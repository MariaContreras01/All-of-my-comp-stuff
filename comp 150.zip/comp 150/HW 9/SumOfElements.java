//method that returns the sum of the elements in the last column of each row of an array
//Maria Contreras
//April 12, 2015

import java.util.*;

public class SumOfElements
{
  private int [][] arr;
  private final int SIZE = 4;
  private int sum = 0;
  public SumOfElements()
  {
    this.arr = new int[SIZE][SIZE];
    Random rand = new Random();
      for ( int r = 0; r < this.arr.length; r++ )
      {
        for ( int c = 0; c < this.arr[r].length; c++ )
        {
          this.arr[r][c]=rand.nextInt(5);
        }
        
      }
  }
  
  public int addColumns()
  {
    for ( int r = 0; r < this.arr.length; r++ )
    {
        sum+=this.arr[r][this.arr[r].length-1];
    }
    return sum;
  }
  
    
  
   public String toString()
    {
        String returnValue = "";
        for (int r = 0; r < SIZE; r++)
        {
            for (int c = 0; c < SIZE; c++)
            {
                returnValue += this.arr[r][c] + " ";
            }
            returnValue += "\n";
        }
        return returnValue += "\n";
    }
 }
