//client class for ArrayListSum
//Maria Contreras
//4-12-15

public class ArrayListSumClient
{
  public static void main( String [] args )
  {
    ArrayListSum arr1 = new ArrayListSum();
    System.out.println( arr1 +
                        "\nThe the sum of the ArrayList  is " + arr1.addInts());
  }
}