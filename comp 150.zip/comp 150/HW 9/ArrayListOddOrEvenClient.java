//client class for ArrayListOddOrEven
//Maria Contreras
//4-12-15

public class ArrayListOddOrEvenClient
{
  public static void main( String [] args )
  {
    ArrayListOddOrEven arr1 = new ArrayListOddOrEven();
    System.out.println( arr1 +
                        "\nThe ArrayList  is " + arr1.findOddOrEven());
  }
}