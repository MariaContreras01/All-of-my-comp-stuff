//client class for AverageOfElements
//Maria Contreras
//4-12-15

public class AverageOfElementsClient
{
  public static void main( String [] args )
  {
    AverageOfElements arr1 = new AverageOfElements();
    System.out.println( arr1 +
                        "\nThe average of array is " + arr1.calculateAverage());
  }
}