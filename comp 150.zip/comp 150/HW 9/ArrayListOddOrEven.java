//Method that returns The Strind odd or even if the elements in an ArrayList of strings are odd or even
//Maria Contreras
//4-12-15

import java.util.*;

public class ArrayListOddOrEven
{
  public ArrayList<String> listOfStrings;
  public String oddOrEven;
  public int sum;
  
  public ArrayListOddOrEven()
  {
    this.listOfStrings = new ArrayList<String>( );
    this.listOfStrings.add(new String("hello"));
    this.listOfStrings.add(new String("how"));
    this.listOfStrings.add(new String("are"));
    this.listOfStrings.add(new String("you"));
    this.listOfStrings.trimToSize( );
  }
  
  public String toString( )
  {
    String result = "";
    for( String tempString : this.listOfStrings )
    {
      result += tempString.toString( ) + "\n";
    }
    return result;
  }
  
  public String findOddOrEven()
  {
    for ( int i= 0; i < listOfStrings.size(); i++ )
    {
      sum += 1;
      if ( sum % 2 == 0 )
      {
        oddOrEven = "even";
       
      }
      else 
      {
        oddOrEven = "odd" ;
       
      }
    }
    return oddOrEven;
  }
  
}