//Program that checks for valid credit card number 
//Maria Contreras
//2-25-15

import java.util.Scanner;

public class CreditCard
{
  public static void main( String [] args )
  {
    
    Scanner scan = new Scanner ( System.in );
    String cardNumber;
    int sum = 0; 
    int checkSum = 0;
    String anotherCard = "";
    int cardNumberInt;
    int oddSum = 0;
    int evenSum = 0;
    do
    {

      do
      {

       //prompt the user for credit card number
       System.out.println( "Enter your credit card number" );
       cardNumber = scan.nextLine();

      }while (!(cardNumber.matches("[0-9]{8}")));

   //Using a for loop go over the input card number, one character at the time starting with the first character (see Lecture Notes Chapter 6 "Processing a String" slide)
     for ( int i = 0; i < cardNumber.length(); i++ );
     {

//     utilize Character.digit method to convert the char to and int
       cardNumberInt = Character.digit( cardNumber.charAt(1), 10 );
//     if the current character is at odd index add the int to sum total
       if ( cardNumberInt % 2 > 0 )
       {
         checkSum = cardNumberInt + oddSum;
       }
//     if the current character is at even index double the int and then utilize division by 10 and modulus by 10 to get the first and last digit respectively, add the digits to the sum total
       if ( cardNumberInt % 2 == 0 )
       {
         checkSum = ((( cardNumberInt * 2 ) / 10) % 10) + evenSum;
       }
     }
   
//          Check if the calculated checkSum ends with zero (again use % operator)
     if ( checkSum % 10 == 0 )
     {
//          Display the results
       System.out.println( "The checkSum is " + checkSum + " The cardNumber " + cardNumber + " is valid" );
    
     }
     
     if ( checkSum % 10 != 0 )
     {
       System.out.println( "The checkSum is " + checkSum + " The cardNumber " + cardNumber + " is NOT valid" );
     }
       
//          Ask the user if (s)he wants to convert another card
       System.out.println( "Would you like to check another credit card? (yes/no)");
       anotherCard = scan.nextLine();
     
    }while (!(anotherCard.equals( "no")));
    
  }
}