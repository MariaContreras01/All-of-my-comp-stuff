//program that takes 5 int values representing exam grades and outputs the minimum value, maximum value,and average
//Maria Contreras
//2-28-15

import java.util.Scanner;
import java.lang.Integer;

public class ExamGrades
{
  public static void main( String [] args )
  {
//    Declare variable minGrade and initialize it to Integer.MAX_VALUE
    Scanner scan = new Scanner( System.in );
    int minGrade = Integer.MAX_VALUE;
//    Declare variable maxGrade and initialize it to Integer.MIN_VALUE
    int maxGrade = Integer.MIN_VALUE;
    int grade;
    double average;
    
    
//    Use a for loop to get 5 values. Inside the for loop:
    for ( int i = 1; i <= 5; i++ )
    {
//        use a do-while loop to make sure that each entered value is in the correct range.
//       
      do
      {   
        System.out.println( "Enter grade " + i );
        grade = scan.nextInt();
      }while ( grade > 100 || grade < 0 );
      
//      calculate requested minimum, maximum, and the running total as the values of grades are entered
      if ( grade > maxGrade )
      {
        maxGrade = grade;
      }
      
      if ( grade < minGrade ) 
      {
        minGrade = grade;
      }
    }
    
//    When outside of the for loop calculate the requested average
  
      average = (double)((minGrade + maxGrade)/2);
    
      
    
//    Display the results 
    System.out.println( "The average grade is " + average + ", the minumum grade is " + minGrade +
                        ", the maximum grade is " + maxGrade );
  }
}
