// First program in Java
// Contreras, Maria

public class FirstProgram
{
  public static void main( String [ ] args )
  {
     System.out.println( "Programming is not a spectator sport!" );
     
     System.exit( 0 );
  }
}

