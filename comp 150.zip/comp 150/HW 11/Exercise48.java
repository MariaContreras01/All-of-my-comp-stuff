//Maria Contreras
// 4-28-15

import java.util.*;
import java.io.*;

public class Exercise48
{
  public static void main( String [] args )
  {
    try
    {
      Scanner file = new Scanner( new File("input.txt") );
      while ( file.hasNext() )
      {
       String line = file.nextLine();
        
        try 
        {
         System.out.println( line + " " );
        }
        
        catch ( InputMismatchException ime )
        {
          System.out.println( "Error in input" );
        } 
        
      }
      
      file.close();
    }
    
      catch ( FileNotFoundException fnfe )
      {
        System.out.println( "Unable to find input.txt" );
      }
      
      catch ( IOException ioe )
      {
        ioe.printStackTrace();
      }
    }
  }