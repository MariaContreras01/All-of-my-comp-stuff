//Maria Contreras
//4-28-15

import java.util.*;
import java.io.*;

public class WordFrequency
{
  private String line;
  private String word;
  public WordFrequency( Scanner scan, String startWord  )
  {
   while( scan.hasNext() )
   {
      try 
      {
        this.line = scan.nextLine();
      }
     
      catch ( InputMismatchException ime )
      {
        System.out.println( scan.nextLine() + "is not a string" );
      }
    }
   
   setWord(startWord);                            
  }
  
  public void setWord( String newWord )
  {
    this.word = newWord;
  }
  
  public int frequency()
  {
    int counter = 0;
    String search = this.line;
    if (search.equals(this.word))
    {
      counter++;
    }
    return counter;
  }
}
