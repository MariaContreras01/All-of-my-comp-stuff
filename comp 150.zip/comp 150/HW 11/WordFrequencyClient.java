//Maria Contreras
//4-28-15

import java.util.*;
import java.io.*;

public class WordFrequencyClient
{
  public static void main(String [] args )
  {
    String fileName;
    String word;
    Scanner scan = new Scanner( System.in );
    
    System.out.println( "enter the name of the file you want to search in" );
    fileName = scan.nextLine();
    
    System.out.println( "enter the word you want to search for" );
    word = scan.next();
    
    try 
    {
      File file = new File( fileName );
      Scanner scanFromFile = new Scanner(file);
      WordFrequency wf = new WordFrequency( scanFromFile, word );
      int frequency = wf.frequency();
      System.out.println( frequency );
    }
    catch ( FileNotFoundException fnfe )
    {
      System.out.println( "unable to find input file " + fileName );
    }
    
  }
}