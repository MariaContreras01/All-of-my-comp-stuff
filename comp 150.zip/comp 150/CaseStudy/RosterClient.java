//Maria Contreras
//4-21-15

import java.util.*;

public class RosterClient
{
  public static void main( String [] args )
  {
    ArrayList<Student> roster = new ArrayList<Student>();
    int numberOfStudents = 40;
    Random random = new Random();
    for ( int s = 0; s < numberOfStudents; s++)
    {
      if (random.nextBoolean())
        roster.add(new UndergraduateStudent("name" + s));
      else 
        roster.add(new GraduateStudent("name" + s));
      for (int t = 1; t <= Student.NUM_OF_TESTS; t++)
      {
        roster.get(s).setTestScore(t, random.nextInt(51) + 50);
      }
    }
    
    for (Student student : roster)
    {
      student.setCourseGrade();
    }
    
    int totalGrads = 0;
    for (Student student : roster) 
    {
      if (student instanceof GraduateStudent)
        totalGrads++;
    }
    
    int totalUndergrads = 0;
    for (Student student : roster)
    {
      if (student instanceof UndergraduateStudent)
        totalUndergrads++;
    }
    System.out.println("*** The roster of " + numberOfStudents + ": " + totalGrads +
                       " graduate students and " + totalUndergrads + " undergraduate " + 
                       "students ***" + "\n" + roster);
  }
}