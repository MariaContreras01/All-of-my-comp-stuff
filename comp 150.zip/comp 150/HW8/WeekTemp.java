/*  Service class that handles daily temperatures for a week 
 *  Maria Contreras
 *  3-31-14
 */

public class WeekTemp
{
  private double [] temperature;
  private final int FREEZING = 32;
  
  public WeekTemp(double [] newArray)
  {
    setTemperature(newArray);
  }
  
  public double [] getTemperature()
  {
    double [] copy = new double [this.temperature.length];
    for (int i = 0; i < this.temperature.length; i++)
    {
      copy[i] = this.temperature[i];
    }
    return copy;
  }
  
  public void setTemperature(double[] newArray)
  {
    this.temperature = new double [newArray.length];
    for (int i = 0; i < newArray.length; i++)
    {
      this.temperature[i] = newArray[i];
    }
  }
  
  public String toString()
  {
    String returnValue = "";
    for ( int i = 0; i < this.temperature.length; i++ )
    {
      returnValue += this.temperature[i] + " ";
    }
    return returnValue += "\n";
  }
  
  public boolean equals (WeekTemp other)
  {
    boolean isEqual = true;
    if ( this.temperature.length != other.temperature.length )
    {
      isEqual = false; 
    }
    else
    {
      for ( int i = 0; i < this.temperature.length && isEqual; i++ )
      {
        if ( this.temperature[i] != other.temperature[i] )
        {
          isEqual = false; 
        }
      }
    }
    return isEqual;
  }

  public int howManyBelowFreezing()
  { 
    int belowFreezing = 0;
    for ( int i = 1; i < this.temperature.length; i++ )
    {
      if ( temperature[i] < FREEZING )
      {
        belowFreezing++;
      }
    }
    return belowFreezing;
  }

  
  public double[] getTemperaturesAbove100( )
  {
    double[] tempAbove100 = new double[this.temperature.length];
    for ( int i = 0; i < this.temperature.length; i ++ )
    {
      if ( this.temperature[i] > 100 )
      {
        tempAbove100[i] = this.temperature[i];
      }
    }
    
    return tempAbove100;
  }
  
  public double getHighest(  )
  {
    int maxValue = 0;
    for ( int i = 1; i < this.temperature.length; i++)
    {
      if ( this.temperature[i] > this.temperature[maxValue] )
      {
        maxValue = i;
      }
    }
    return this.temperature[maxValue];
  }
}