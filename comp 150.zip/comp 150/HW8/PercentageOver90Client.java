/* client class for PercentageOver90
 * Maria Contreras
 * March 31st 2015
 */

public class PercentageOver90Client
{
  public static void main( String [] args )
  {
    int [] numbers1 = { 1, 2, 3, 4, 5, 6};
    PercentageOver90 arr1 = new PercentageOver90( numbers1 );
    System.out.println( arr1.percent() + "%" );
    
    int [] numbers2 = { 1, 90, 5, 49, 90, 90};
    PercentageOver90 arr2 = new PercentageOver90( numbers2 );
    System.out.println( arr2.percent() + "%" );
    
    int [] numbers3 = { 90, 90, 90, 90, 90, 90};
    PercentageOver90 arr3 = new PercentageOver90( numbers3 );
    System.out.println( arr3.percent() + "%" );
  }
}