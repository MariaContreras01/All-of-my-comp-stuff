/* business method that returns the percentage of elements in an array over 90
 * Maria Contreras
 * March 31st 2015
 */

public class PercentageOver90
{
  private int [] intArray;
  private int DEFAULT_SIZE = 10;
  
  public PercentageOver90()
  {
    this.intArray = new int [DEFAULT_SIZE];
  }
  
  public PercentageOver90( int [] newArr )
  {
    setIntArray(newArr);
  }
  
  public void setIntArray(int[] newArray)
  {
    this.intArray = new int [newArray.length];
    for (int i = 0; i < newArray.length; i++)
    {
      this.intArray[i] = newArray[i];
    }
  }
  
  public int getLength()
  {
    return this.intArray.length;
  }
  
  public double percent()
  {
    double count = 0;
    double percentage = 0;
    for ( int i = 0; i < intArray.length; i++ )
    {
      if ( intArray[i] >= 90 )
      {
        count++;
      }
    }  
   double length = (double)intArray.length;
    percentage = (count / length) * 100;
    
    
    return percentage;
  }
  
}