/* business method that assigns true to elements of an array over 100
 * Maria Contreras
 * March 31st 2015
 */

public class AssignTrue
{
  private int [] intArray;
  private int DEFAULT_SIZE = 10;
  
  public AssignTrue()
  {
    this.intArray = new int [DEFAULT_SIZE];
  }
  
  public AssignTrue( int [] newArr )
  {
    setIntArray(newArr);
  }
  
  public void setIntArray(int[] newArray)
  {
    this.intArray = new int [newArray.length];
    for (int i = 0; i < newArray.length; i++)
    {
      this.intArray[i] = newArray[i];
    }
  }
  
  public int getLength()
  {
    return this.intArray.length;
  }
  
  public boolean [] toBoolean()
  {
    boolean assignment = false;
    for ( int i = 1; i < this.intArray.length; i++ )
    {
      if ( this.intArray[i] >= 100 )
      {
        assignment = true;
      }
    }
    boolean [] newArray = {assignment};
    return newArray;
  }
}