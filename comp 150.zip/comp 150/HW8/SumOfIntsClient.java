/* client class for SumOfInts
 * Maria Contreras
 * March 31st 2015
 */

public class SumOfIntsClient
{
  public static void main( String [] args )
  {
    int [] numbers = { 1, 2, 3, 4, 5, 6};
    SumOfInts arr = new SumOfInts( numbers );
    System.out.println( arr.sumOfEvenIndex() );
  }
}