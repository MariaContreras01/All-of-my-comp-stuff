/* client class for AssignTrue
 * Maria Contreras
 * March 31st 2015
 */

public class AssignTrueClient
{
  public static void main( String [] args )
  {
    int [] numbers = { 1, 2, 3, 4, 5, 6};
    AssignTrue arr1 = new AssignTrue( numbers );
    System.out.println( arr1.toBoolean());
  }
}