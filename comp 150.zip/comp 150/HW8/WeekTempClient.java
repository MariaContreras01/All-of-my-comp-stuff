/* WeekTemp client
 * Maria Contreras
 * 3-31-14
 */

public class WeekTempClient
{
  public static void main( String [] args )
  {
    double [] numbers = {57, 120, 25, 67, 45, 89, 77};
    WeekTemp week = new WeekTemp( numbers );
    System.out.println( "The temperatures are " + week.getTemperature() );
    System.out.println( "The amounts below freezing are " + week.howManyBelowFreezing() );
    System.out.println( "The temperatures above 100 are " + week.getTemperaturesAbove100() );
    System.out.println( "The highest temperature is " + week.getHighest() );
  }
}